import { CloudOff, Info } from 'lucide-react'
import { isFirebaseConfigured } from '@/lib/firebase'
import { cn } from '@/lib/utils'

interface BackendNoticeProps {
  feature: string
  /** Set when this feature is session-only even after Firebase is configured. */
  pendingIntegration?: boolean
  className?: string
}

export function BackendNotice({ feature, pendingIntegration, className }: BackendNoticeProps) {
  if (isFirebaseConfigured && !pendingIntegration) return null

  const Icon = isFirebaseConfigured ? Info : CloudOff
  const message = isFirebaseConfigured
    ? `${feature} is not yet saved to Cloud Firestore. Data entered here lasts for this browser session only.`
    : `Firebase is not connected, so ${feature.toLowerCase()} cannot load or save real data yet. This page shows the layout only.`

  return (
    <div
      role="status"
      className={cn(
        'flex items-start gap-3 rounded-lg border border-primary/20 bg-primary/5 px-4 py-3 text-sm text-foreground',
        className,
      )}
    >
      <Icon className="mt-0.5 size-4 shrink-0 text-primary" aria-hidden="true" />
      <p className="text-pretty">{message}</p>
    </div>
  )
}
