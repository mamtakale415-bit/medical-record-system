import type { ReactNode } from 'react'
import { cn } from '@/lib/utils'

export interface Column<T> {
  header: string
  cell: (row: T) => ReactNode
  className?: string
}

interface DataTableProps<T> {
  caption: string
  columns: Column<T>[]
  rows: T[]
  getRowKey: (row: T) => string
  empty: ReactNode
}

export function DataTable<T>({ caption, columns, rows, getRowKey, empty }: DataTableProps<T>) {
  if (rows.length === 0) return <>{empty}</>

  return (
    <div className="overflow-x-auto rounded-lg border">
      <table className="w-full min-w-xl text-left text-sm">
        <caption className="sr-only">{caption}</caption>
        <thead className="bg-muted/60 text-xs uppercase tracking-wide text-muted-foreground">
          <tr>
            {columns.map((col) => (
              <th key={col.header} scope="col" className={cn('px-4 py-2.5 font-medium', col.className)}>
                {col.header}
              </th>
            ))}
          </tr>
        </thead>
        <tbody className="divide-y">
          {rows.map((row) => (
            <tr key={getRowKey(row)} className="bg-card hover:bg-muted/30">
              {columns.map((col) => (
                <td key={col.header} className={cn('px-4 py-3 align-middle', col.className)}>
                  {col.cell(row)}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}
