import { HeartPulse } from 'lucide-react'
import { Link } from 'react-router-dom'
import { cn } from '@/lib/utils'

export function Logo({ to = '/', className }: { to?: string; className?: string }) {
  return (
    <Link to={to} className={cn('flex items-center gap-2 font-semibold', className)}>
      <span className="flex size-8 items-center justify-center rounded-lg bg-primary text-primary-foreground">
        <HeartPulse className="size-4.5" aria-hidden="true" />
      </span>
      <span className="text-lg tracking-tight">
        Care<span className="text-primary">Cloud</span>
      </span>
    </Link>
  )
}
