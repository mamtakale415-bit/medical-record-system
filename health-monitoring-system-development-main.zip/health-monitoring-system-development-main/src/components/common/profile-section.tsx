import type { ReactNode } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Field, Input, Select, Textarea } from '@/components/ui/form-controls'

export interface ProfileFieldDef {
  id: string
  label: string
  type?: 'text' | 'email' | 'tel' | 'date' | 'number' | 'textarea' | 'select'
  options?: string[]
  defaultValue?: string
  full?: boolean
}

interface ProfileSectionProps {
  title: string
  description?: string
  fields: ProfileFieldDef[]
  disabled?: boolean
  footer?: ReactNode
}

export function ProfileSection({ title, description, fields, disabled, footer }: ProfileSectionProps) {
  return (
    <Card>
      <CardHeader>
        <CardTitle>{title}</CardTitle>
        {description ? <CardDescription>{description}</CardDescription> : null}
      </CardHeader>
      <CardContent className="flex flex-col gap-4">
        <div className="grid gap-4 sm:grid-cols-2">
          {fields.map((f) => (
            <Field key={f.id} id={f.id} label={f.label} className={f.full ? 'sm:col-span-2' : undefined}>
              {f.type === 'textarea' ? (
                <Textarea id={f.id} defaultValue={f.defaultValue} disabled={disabled} />
              ) : f.type === 'select' ? (
                <Select id={f.id} defaultValue={f.defaultValue ?? ''} disabled={disabled}>
                  <option value="">Not specified</option>
                  {f.options?.map((o) => (
                    <option key={o} value={o}>{o}</option>
                  ))}
                </Select>
              ) : (
                <Input id={f.id} type={f.type ?? 'text'} defaultValue={f.defaultValue} disabled={disabled} />
              )}
            </Field>
          ))}
        </div>
        {footer}
      </CardContent>
    </Card>
  )
}
