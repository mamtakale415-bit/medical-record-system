import { Search } from 'lucide-react'
import { Input, Select } from '@/components/ui/form-controls'

interface FilterOption {
  value: string
  label: string
}

interface SearchFilterBarProps {
  searchLabel: string
  search: string
  onSearchChange: (value: string) => void
  filterLabel?: string
  filter?: string
  onFilterChange?: (value: string) => void
  filterOptions?: FilterOption[]
}

export function SearchFilterBar({
  searchLabel,
  search,
  onSearchChange,
  filterLabel,
  filter,
  onFilterChange,
  filterOptions,
}: SearchFilterBarProps) {
  return (
    <div className="flex flex-col gap-2 sm:flex-row">
      <div className="relative flex-1">
        <Search
          className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground"
          aria-hidden="true"
        />
        <label htmlFor="search-input" className="sr-only">
          {searchLabel}
        </label>
        <Input
          id="search-input"
          type="search"
          placeholder={searchLabel}
          value={search}
          onChange={(e) => onSearchChange(e.target.value)}
          className="pl-9"
        />
      </div>
      {filterOptions && onFilterChange ? (
        <>
          <label htmlFor="filter-select" className="sr-only">
            {filterLabel}
          </label>
          <Select
            id="filter-select"
            value={filter}
            onChange={(e) => onFilterChange(e.target.value)}
            className="sm:w-48"
          >
            {filterOptions.map((option) => (
              <option key={option.value} value={option.value}>
                {option.label}
              </option>
            ))}
          </Select>
        </>
      ) : null}
    </div>
  )
}
