import { AlertTriangle, CheckCircle2, Cpu, OctagonAlert, PencilLine } from 'lucide-react'
import { Badge } from '@/components/ui/badge'
import { STATUS_LABELS } from '@/lib/health'
import type { IndicatorStatus, ReadingSource } from '@/types'

const statusConfig = {
  normal: { variant: 'success', icon: CheckCircle2 },
  warning: { variant: 'warning', icon: AlertTriangle },
  critical: { variant: 'critical', icon: OctagonAlert },
} as const

export function IndicatorBadge({ status }: { status: IndicatorStatus }) {
  const { variant, icon: Icon } = statusConfig[status]
  return (
    <Badge variant={variant}>
      <Icon aria-hidden="true" />
      {STATUS_LABELS[status]}
    </Badge>
  )
}

export function SourceBadge({ source }: { source: ReadingSource }) {
  if (source === 'device') {
    return (
      <Badge variant="default">
        <Cpu aria-hidden="true" />
        Connected device
      </Badge>
    )
  }
  return (
    <Badge variant="outline">
      <PencilLine aria-hidden="true" />
      Manual entry
    </Badge>
  )
}
