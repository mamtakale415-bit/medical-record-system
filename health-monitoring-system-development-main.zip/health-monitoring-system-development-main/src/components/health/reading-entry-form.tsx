import { PencilLine } from 'lucide-react'
import { useState, type FormEvent } from 'react'
import { FormAlert } from '@/components/common/form-alert'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Field, Input, Textarea } from '@/components/ui/form-controls'
import { useHealthData } from '@/contexts/health-data-context'
import { VITAL_KEYS, VITALS } from '@/lib/health'
import type { VitalKey } from '@/types'

function nowLocalInput() {
  const d = new Date()
  d.setMinutes(d.getMinutes() - d.getTimezoneOffset())
  return d.toISOString().slice(0, 16)
}

export function ReadingEntryForm() {
  const { addReading } = useHealthData()
  const [values, setValues] = useState<Partial<Record<VitalKey, string>>>({})
  const [recordedAt, setRecordedAt] = useState(nowLocalInput)
  const [notes, setNotes] = useState('')
  const [message, setMessage] = useState<{ tone: 'error' | 'success'; text: string } | null>(null)

  function handleSubmit(event: FormEvent) {
    event.preventDefault()
    const parsed: Partial<Record<VitalKey, number>> = {}
    for (const key of VITAL_KEYS) {
      const raw = values[key]?.trim()
      if (!raw) continue
      const num = Number(raw)
      const meta = VITALS[key]
      if (Number.isNaN(num) || num < meta.min || num > meta.max) {
        setMessage({ tone: 'error', text: `${meta.label} must be between ${meta.min} and ${meta.max} ${meta.unit}.` })
        return
      }
      parsed[key] = num
    }
    if (Object.keys(parsed).length === 0) {
      setMessage({ tone: 'error', text: 'Enter at least one measurement.' })
      return
    }
    if ((parsed.systolic === undefined) !== (parsed.diastolic === undefined)) {
      setMessage({ tone: 'error', text: 'Enter both systolic and diastolic values for blood pressure.' })
      return
    }
    const when = new Date(recordedAt)
    if (Number.isNaN(when.getTime()) || when.getTime() > Date.now() + 60_000) {
      setMessage({ tone: 'error', text: 'The reading time cannot be in the future.' })
      return
    }
    addReading({ ...parsed, recordedAt: when.toISOString(), source: 'manual', notes: notes.trim() || undefined })
    setValues({})
    setNotes('')
    setRecordedAt(nowLocalInput())
    setMessage({ tone: 'success', text: 'Manual reading added for this session.' })
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <PencilLine className="size-4 text-primary" aria-hidden="true" />
          Manual reading entry
        </CardTitle>
        <CardDescription>
          Readings entered here are labelled as manual. Device readings arrive separately and are labelled as connected-device data.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="flex flex-col gap-4" noValidate>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {VITAL_KEYS.map((key) => {
              const meta = VITALS[key]
              return (
                <Field key={key} id={`reading-${key}`} label={`${meta.label} (${meta.unit})`}>
                  <Input
                    id={`reading-${key}`}
                    type="number"
                    inputMode="decimal"
                    step={meta.step}
                    min={meta.min}
                    max={meta.max}
                    value={values[key] ?? ''}
                    onChange={(e) => setValues((prev) => ({ ...prev, [key]: e.target.value }))}
                  />
                </Field>
              )
            })}
            <Field id="reading-time" label="Recorded at">
              <Input
                id="reading-time"
                type="datetime-local"
                value={recordedAt}
                max={nowLocalInput()}
                onChange={(e) => setRecordedAt(e.target.value)}
                required
              />
            </Field>
          </div>
          <Field id="reading-notes" label="Notes (optional)">
            <Textarea
              id="reading-notes"
              value={notes}
              maxLength={500}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Context such as after exercise, fasting, or medication timing"
            />
          </Field>
          {message ? <FormAlert tone={message.tone} message={message.text} /> : null}
          <div>
            <Button type="submit" size="lg" className="px-4">Add reading</Button>
          </div>
        </form>
      </CardContent>
    </Card>
  )
}
