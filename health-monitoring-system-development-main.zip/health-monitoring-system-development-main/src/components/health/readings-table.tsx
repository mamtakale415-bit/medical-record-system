import { Activity } from 'lucide-react'
import { DataTable, type Column } from '@/components/common/data-table'
import { EmptyState } from '@/components/common/empty-state'
import { IndicatorBadge, SourceBadge } from '@/components/common/status-badge'
import { evaluateReading, formatDateTime, RANGED_VITAL_KEYS } from '@/lib/health'
import type { HealthReading, IndicatorStatus, ReferenceRanges } from '@/types'

const severity: Record<IndicatorStatus, number> = { normal: 0, warning: 1, critical: 2 }

function overallStatus(reading: HealthReading, ranges: ReferenceRanges): IndicatorStatus | null {
  let worst: IndicatorStatus | null = null
  for (const key of RANGED_VITAL_KEYS) {
    const value = reading[key]
    if (value === undefined) continue
    const status = evaluateReading(value, ranges[key])
    if (!worst || severity[status] > severity[worst]) worst = status
  }
  return worst
}

const dash = (v?: number) => (v === undefined ? '—' : v)

export function ReadingsTable({ readings, ranges }: { readings: HealthReading[]; ranges: ReferenceRanges }) {
  const columns: Column<HealthReading>[] = [
    { header: 'Recorded', cell: (r) => <span className="whitespace-nowrap">{formatDateTime(r.recordedAt)}</span> },
    { header: 'Source', cell: (r) => <SourceBadge source={r.source} /> },
    { header: 'HR', cell: (r) => dash(r.heartRate), className: 'tabular-nums' },
    { header: 'BP', cell: (r) => (r.systolic ? `${r.systolic}/${r.diastolic}` : '—'), className: 'tabular-nums' },
    { header: 'Glucose', cell: (r) => dash(r.glucose), className: 'tabular-nums' },
    { header: 'Temp', cell: (r) => dash(r.temperature), className: 'tabular-nums' },
    { header: 'SpO₂', cell: (r) => dash(r.spo2), className: 'tabular-nums' },
    { header: 'Weight', cell: (r) => dash(r.weight), className: 'tabular-nums' },
    {
      header: 'Indicator',
      cell: (r) => {
        const status = overallStatus(r, ranges)
        return status ? <IndicatorBadge status={status} /> : '—'
      },
    },
  ]

  return (
    <DataTable
      caption="Health readings, newest first"
      columns={columns}
      rows={[...readings].reverse()}
      getRowKey={(r) => r.id}
      empty={
        <EmptyState
          icon={Activity}
          title="No readings yet"
          description="Manual entries and connected-device readings will be listed here."
        />
      }
    />
  )
}
