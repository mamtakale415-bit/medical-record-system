import { SlidersHorizontal } from 'lucide-react'
import { useState } from 'react'
import { FormAlert } from '@/components/common/form-alert'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/form-controls'
import { useHealthData } from '@/contexts/health-data-context'
import { RANGED_VITAL_KEYS, validateRange, VITALS } from '@/lib/health'
import type { RangedVitalKey, ReferenceRange } from '@/types'

const FIELDS: { key: keyof ReferenceRange; label: string }[] = [
  { key: 'warningMin', label: 'Warning min' },
  { key: 'normalMin', label: 'Normal min' },
  { key: 'normalMax', label: 'Normal max' },
  { key: 'warningMax', label: 'Warning max' },
]

export function ReferenceRangeEditor({ readOnly }: { readOnly?: boolean }) {
  const { ranges, updateRange, resetRanges } = useHealthData()
  const [drafts, setDrafts] = useState(ranges)
  const [message, setMessage] = useState<{ tone: 'error' | 'success'; text: string } | null>(null)

  function setValue(vital: RangedVitalKey, field: keyof ReferenceRange, value: string) {
    setDrafts((prev) => ({ ...prev, [vital]: { ...prev[vital], [field]: Number(value) } }))
  }

  function handleSave() {
    for (const key of RANGED_VITAL_KEYS) {
      const error = validateRange(drafts[key])
      if (error) {
        setMessage({ tone: 'error', text: `${VITALS[key].label}: ${error}` })
        return
      }
    }
    RANGED_VITAL_KEYS.forEach((key) => updateRange(key, drafts[key]))
    setMessage({ tone: 'success', text: 'Reference ranges updated for this session.' })
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <SlidersHorizontal className="size-4 text-primary" aria-hidden="true" />
          Reference ranges
        </CardTitle>
        <CardDescription>
          Values inside the normal range show as Normal, inside the warning range as Warning, and outside it as Critical.
          Defaults are general adult values — care teams should adjust them per patient.
        </CardDescription>
      </CardHeader>
      <CardContent className="flex flex-col gap-4">
        <div className="overflow-x-auto rounded-lg border">
          <table className="w-full min-w-xl text-sm">
            <caption className="sr-only">Editable reference ranges per vital sign</caption>
            <thead className="bg-muted/60 text-left text-xs uppercase tracking-wide text-muted-foreground">
              <tr>
                <th scope="col" className="px-4 py-2.5 font-medium">Vital</th>
                {FIELDS.map((f) => (
                  <th key={f.key} scope="col" className="px-3 py-2.5 font-medium">{f.label}</th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y">
              {RANGED_VITAL_KEYS.map((key) => (
                <tr key={key}>
                  <th scope="row" className="px-4 py-2 text-left font-medium">
                    {VITALS[key].label}
                    <span className="block text-xs font-normal text-muted-foreground">{VITALS[key].unit}</span>
                  </th>
                  {FIELDS.map((f) => (
                    <td key={f.key} className="px-3 py-2">
                      <Input
                        type="number"
                        step={VITALS[key].step}
                        aria-label={`${VITALS[key].label} ${f.label}`}
                        value={Number.isNaN(drafts[key][f.key]) ? '' : drafts[key][f.key]}
                        onChange={(e) => setValue(key, f.key, e.target.value)}
                        disabled={readOnly}
                        className="w-24"
                      />
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {message ? <FormAlert tone={message.tone} message={message.text} /> : null}
        {readOnly ? (
          <p className="text-sm text-muted-foreground">Only your care team can change reference ranges.</p>
        ) : (
          <div className="flex flex-wrap gap-2">
            <Button size="lg" className="px-4" onClick={handleSave}>Save ranges</Button>
            <Button
              size="lg"
              variant="outline"
              className="px-4"
              onClick={() => {
                resetRanges()
                setMessage(null)
                setDrafts(ranges)
              }}
            >
              Reset to defaults
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
