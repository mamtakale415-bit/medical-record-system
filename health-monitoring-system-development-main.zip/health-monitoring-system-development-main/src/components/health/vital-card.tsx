import type { LucideIcon } from 'lucide-react'
import { IndicatorBadge, SourceBadge } from '@/components/common/status-badge'
import { Card } from '@/components/ui/card'
import { evaluateReading, formatDateTime } from '@/lib/health'
import type { HealthReading, ReferenceRange } from '@/types'

interface VitalCardProps {
  label: string
  icon: LucideIcon
  unit: string
  value: string | null
  numericValue?: number
  range?: ReferenceRange
  reading?: HealthReading
}

export function VitalCard({ label, icon: Icon, unit, value, numericValue, range, reading }: VitalCardProps) {
  const status = numericValue !== undefined && range ? evaluateReading(numericValue, range) : null

  return (
    <Card className="flex flex-col gap-3 p-5">
      <div className="flex items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <span className="flex size-8 items-center justify-center rounded-lg bg-accent text-accent-foreground">
            <Icon className="size-4" aria-hidden="true" />
          </span>
          <h3 className="text-sm font-medium text-muted-foreground">{label}</h3>
        </div>
        {status ? <IndicatorBadge status={status} /> : null}
      </div>
      <p className="flex items-baseline gap-1">
        <span className="text-3xl font-semibold tabular-nums">{value ?? '—'}</span>
        <span className="text-sm text-muted-foreground">{unit}</span>
      </p>
      {reading ? (
        <div className="flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
          <SourceBadge source={reading.source} />
          <span>{formatDateTime(reading.recordedAt)}</span>
        </div>
      ) : (
        <p className="text-xs text-muted-foreground">No readings recorded yet</p>
      )}
    </Card>
  )
}
