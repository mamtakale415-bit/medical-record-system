import { LineChart as LineChartIcon } from 'lucide-react'
import {
  CartesianGrid,
  Line,
  LineChart,
  ReferenceArea,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts'
import { EmptyState } from '@/components/common/empty-state'
import { VITALS } from '@/lib/health'
import type { HealthReading, ReferenceRange, VitalKey } from '@/types'

interface VitalTrendChartProps {
  readings: HealthReading[]
  vitals: VitalKey[]
  range?: ReferenceRange
}

interface ChartPoint {
  time: string
  source: string
  [key: string]: string | number | undefined
}

export function VitalTrendChart({ readings, vitals, range }: VitalTrendChartProps) {
  const data: ChartPoint[] = readings
    .filter((r) => vitals.some((key) => r[key] !== undefined))
    .map((r) => ({
      time: new Date(r.recordedAt).toLocaleString(undefined, { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' }),
      source: r.source === 'device' ? 'Connected device' : 'Manual entry',
      ...Object.fromEntries(vitals.map((key) => [key, r[key]])),
    }))

  if (data.length === 0) {
    return (
      <EmptyState
        icon={LineChartIcon}
        title="No data to chart yet"
        description="Add a reading to see its trend over time. Charts update as new readings arrive."
      />
    )
  }

  return (
    <div className="h-72 w-full" role="img" aria-label={`Trend chart of ${vitals.map((v) => VITALS[v].label).join(' and ')}`}>
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={data} margin={{ top: 8, right: 12, bottom: 0, left: -12 }}>
          <CartesianGrid stroke="var(--border)" strokeDasharray="3 3" vertical={false} />
          <XAxis dataKey="time" tick={{ fontSize: 12, fill: 'var(--muted-foreground)' }} tickLine={false} axisLine={false} />
          <YAxis tick={{ fontSize: 12, fill: 'var(--muted-foreground)' }} tickLine={false} axisLine={false} domain={['auto', 'auto']} />
          {range ? (
            <ReferenceArea y1={range.normalMin} y2={range.normalMax} fill="var(--success)" fillOpacity={0.08} ifOverflow="extendDomain" />
          ) : null}
          <Tooltip
            contentStyle={{
              background: 'var(--card)',
              border: '1px solid var(--border)',
              borderRadius: 8,
              fontSize: 12,
            }}
            formatter={(value, name) => {
              const meta = VITALS[name as VitalKey]
              return [`${value} ${meta?.unit ?? ''}`, meta?.label ?? name]
            }}
            labelFormatter={(label, payload) => {
              const source = payload?.[0]?.payload?.source
              return source ? `${label} · ${source}` : label
            }}
          />
          {vitals.map((key) => (
            <Line
              key={key}
              type="monotone"
              dataKey={key}
              name={key}
              stroke={VITALS[key].chartColor}
              strokeWidth={2}
              dot={{ r: 3 }}
              connectNulls
            />
          ))}
        </LineChart>
      </ResponsiveContainer>
    </div>
  )
}
