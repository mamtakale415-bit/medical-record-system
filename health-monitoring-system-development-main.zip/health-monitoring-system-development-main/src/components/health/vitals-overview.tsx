import { Droplet, Gauge, HeartPulse, Scale, Thermometer, Wind } from 'lucide-react'
import { useHealthData } from '@/contexts/health-data-context'
import { VITALS } from '@/lib/health'
import type { HealthReading, VitalKey } from '@/types'
import { VitalCard } from './vital-card'

function latestWith(readings: HealthReading[], key: VitalKey) {
  for (let i = readings.length - 1; i >= 0; i--) {
    if (readings[i][key] !== undefined) return readings[i]
  }
  return undefined
}

export function VitalsOverview() {
  const { readings, ranges } = useHealthData()

  const hr = latestWith(readings, 'heartRate')
  const bp = latestWith(readings, 'systolic')
  const glu = latestWith(readings, 'glucose')
  const temp = latestWith(readings, 'temperature')
  const spo2 = latestWith(readings, 'spo2')
  const wt = latestWith(readings, 'weight')

  const bpStatusValue = bp?.systolic
  return (
    <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
      <VitalCard
        label={VITALS.heartRate.label}
        icon={HeartPulse}
        unit={VITALS.heartRate.unit}
        value={hr?.heartRate?.toString() ?? null}
        numericValue={hr?.heartRate}
        range={ranges.heartRate}
        reading={hr}
      />
      <VitalCard
        label="Blood pressure"
        icon={Gauge}
        unit="mmHg"
        value={bp ? `${bp.systolic}/${bp.diastolic ?? '—'}` : null}
        numericValue={bpStatusValue}
        range={ranges.systolic}
        reading={bp}
      />
      <VitalCard
        label={VITALS.glucose.label}
        icon={Droplet}
        unit={VITALS.glucose.unit}
        value={glu?.glucose?.toString() ?? null}
        numericValue={glu?.glucose}
        range={ranges.glucose}
        reading={glu}
      />
      <VitalCard
        label={VITALS.temperature.label}
        icon={Thermometer}
        unit={VITALS.temperature.unit}
        value={temp?.temperature?.toFixed(1) ?? null}
        numericValue={temp?.temperature}
        range={ranges.temperature}
        reading={temp}
      />
      <VitalCard
        label={VITALS.spo2.label}
        icon={Wind}
        unit={VITALS.spo2.unit}
        value={spo2?.spo2?.toString() ?? null}
        numericValue={spo2?.spo2}
        range={ranges.spo2}
        reading={spo2}
      />
      <VitalCard
        label={VITALS.weight.label}
        icon={Scale}
        unit={VITALS.weight.unit}
        value={wt?.weight?.toFixed(1) ?? null}
        reading={wt}
      />
    </div>
  )
}
