import { useState } from 'react'
import { Outlet } from 'react-router-dom'
import { useAuth } from '@/contexts/auth-context'
import { Sidebar } from './sidebar'
import { Topbar } from './topbar'

export function AppShell() {
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const { isPreview } = useAuth()

  return (
    <div className="flex min-h-dvh bg-background">
      <Sidebar open={sidebarOpen} onClose={() => setSidebarOpen(false)} />
      <div className="flex min-w-0 flex-1 flex-col">
        {isPreview ? (
          <p className="bg-primary px-4 py-1.5 text-center text-xs font-medium text-primary-foreground">
            Layout preview — Firebase is not connected. No real accounts or patient data are loaded.
          </p>
        ) : null}
        <Topbar onMenuClick={() => setSidebarOpen(true)} />
        <main className="mx-auto flex w-full max-w-7xl flex-1 flex-col gap-6 p-4 sm:p-6 lg:p-8">
          <Outlet />
        </main>
      </div>
    </div>
  )
}
