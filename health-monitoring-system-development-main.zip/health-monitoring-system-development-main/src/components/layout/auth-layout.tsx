import { HeartPulse, LineChart, ShieldCheck } from 'lucide-react'
import type { ReactNode } from 'react'
import { Logo } from '@/components/common/logo'

interface AuthLayoutProps {
  title: string
  description: string
  children: ReactNode
}

const highlights = [
  { icon: LineChart, text: 'Track vitals with clear trend charts' },
  { icon: HeartPulse, text: 'Manual and device readings kept distinct' },
  { icon: ShieldCheck, text: 'Role-based access for every record' },
]

export function AuthLayout({ title, description, children }: AuthLayoutProps) {
  return (
    <div className="grid min-h-dvh lg:grid-cols-2">
      <div className="flex flex-col px-4 py-6 sm:px-8">
        <Logo />
        <main className="mx-auto flex w-full max-w-md flex-1 flex-col justify-center gap-6 py-10">
          <div className="flex flex-col gap-1.5">
            <h1 className="text-2xl font-semibold tracking-tight">{title}</h1>
            <p className="text-sm text-muted-foreground">{description}</p>
          </div>
          {children}
        </main>
      </div>
      <aside className="hidden flex-col justify-center gap-8 bg-primary p-12 text-primary-foreground lg:flex">
        <p className="max-w-md text-3xl font-semibold leading-tight text-balance">
          One secure place for patients and care teams to follow health over time.
        </p>
        <ul className="flex flex-col gap-4">
          {highlights.map(({ icon: Icon, text }) => (
            <li key={text} className="flex items-center gap-3 text-primary-foreground/90">
              <span className="flex size-9 items-center justify-center rounded-lg bg-primary-foreground/15">
                <Icon className="size-4" aria-hidden="true" />
              </span>
              {text}
            </li>
          ))}
        </ul>
      </aside>
    </div>
  )
}
