import {
  Activity,
  Bell,
  CalendarClock,
  FileText,
  LayoutDashboard,
  Pill,
  Settings,
  Stethoscope,
  Upload,
  UserRound,
  type LucideIcon,
} from 'lucide-react'
import type { Role } from '@/types'

export interface NavItem {
  label: string
  to: string
  icon: LucideIcon
  roles: Role[]
}

export const NAV_ITEMS: NavItem[] = [
  { label: 'Dashboard', to: '/app/admin', icon: LayoutDashboard, roles: ['admin'] },
  { label: 'Dashboard', to: '/app/doctor', icon: LayoutDashboard, roles: ['doctor'] },
  { label: 'Dashboard', to: '/app/patient', icon: LayoutDashboard, roles: ['patient'] },
  { label: 'My profile', to: '/app/profile/patient', icon: UserRound, roles: ['patient'] },
  { label: 'My profile', to: '/app/profile/doctor', icon: Stethoscope, roles: ['doctor'] },
  { label: 'Health monitoring', to: '/app/monitoring', icon: Activity, roles: ['doctor', 'patient'] },
  { label: 'Medical records', to: '/app/records', icon: FileText, roles: ['admin', 'doctor', 'patient'] },
  { label: 'Upload reports', to: '/app/reports/upload', icon: Upload, roles: ['doctor', 'patient'] },
  { label: 'Appointments', to: '/app/appointments', icon: CalendarClock, roles: ['admin', 'doctor', 'patient'] },
  { label: 'Prescriptions', to: '/app/prescriptions', icon: Pill, roles: ['doctor', 'patient'] },
  { label: 'Notifications', to: '/app/notifications', icon: Bell, roles: ['admin', 'doctor', 'patient'] },
  { label: 'Settings', to: '/app/settings', icon: Settings, roles: ['admin', 'doctor', 'patient'] },
]

export const DASHBOARD_PATH: Record<Role, string> = {
  admin: '/app/admin',
  doctor: '/app/doctor',
  patient: '/app/patient',
}

export const ROLE_LABELS: Record<Role, string> = {
  admin: 'Administrator',
  doctor: 'Doctor',
  patient: 'Patient',
}
