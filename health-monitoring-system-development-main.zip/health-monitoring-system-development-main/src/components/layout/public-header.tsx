import { Link } from 'react-router-dom'
import { Logo } from '@/components/common/logo'
import { buttonVariants } from '@/components/ui/button'

export function PublicHeader() {
  return (
    <header className="sticky top-0 z-20 border-b bg-card/90 backdrop-blur">
      <div className="mx-auto flex h-16 max-w-6xl items-center justify-between gap-4 px-4 sm:px-6">
        <Logo />
        <nav aria-label="Primary" className="hidden items-center gap-6 text-sm text-muted-foreground md:flex">
          <a href="#features" className="hover:text-foreground">Features</a>
          <a href="#roles" className="hover:text-foreground">Who it&apos;s for</a>
          <a href="#security" className="hover:text-foreground">Security</a>
        </nav>
        <div className="flex items-center gap-2">
          <Link to="/login" className={buttonVariants({ variant: 'ghost', size: 'lg' })}>
            Sign in
          </Link>
          <Link to="/register" className={buttonVariants({ size: 'lg', className: 'px-4' })}>
            Register
          </Link>
        </div>
      </div>
    </header>
  )
}
