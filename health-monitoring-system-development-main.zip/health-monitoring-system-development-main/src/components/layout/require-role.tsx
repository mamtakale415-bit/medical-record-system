import { Loader2, ShieldAlert } from 'lucide-react'
import type { ReactNode } from 'react'
import { Link, Navigate, useLocation } from 'react-router-dom'
import { EmptyState } from '@/components/common/empty-state'
import { buttonVariants } from '@/components/ui/button'
import { useAuth } from '@/contexts/auth-context'
import type { Role } from '@/types'
import { DASHBOARD_PATH } from './nav-config'

interface RequireRoleProps {
  roles?: Role[]
  children: ReactNode
}

/**
 * Client-side guard for navigation only. Real enforcement lives in
 * firestore.rules and storage.rules, which check the role stored in users/{uid}.
 */
export function RequireRole({ roles, children }: RequireRoleProps) {
  const { status, role } = useAuth()
  const location = useLocation()

  if (status === 'loading') {
    return (
      <div className="flex min-h-dvh items-center justify-center" role="status">
        <Loader2 className="size-6 animate-spin text-primary" aria-hidden="true" />
        <span className="sr-only">Loading account</span>
      </div>
    )
  }

  if (status === 'signed-out' || !role) {
    return <Navigate to="/login" replace state={{ from: location.pathname }} />
  }

  if (roles && !roles.includes(role)) {
    return (
      <EmptyState
        icon={ShieldAlert}
        title="This page isn't available for your role"
        description="Your account does not have permission to view this section."
        action={
          <Link to={DASHBOARD_PATH[role]} className={buttonVariants({ variant: 'outline' })}>
            Go to your dashboard
          </Link>
        }
      />
    )
  }

  return <>{children}</>
}

export function RoleHomeRedirect() {
  const { role } = useAuth()
  return <Navigate to={role ? DASHBOARD_PATH[role] : '/login'} replace />
}
