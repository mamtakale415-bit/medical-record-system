import { ShieldCheck, X } from 'lucide-react'
import { NavLink } from 'react-router-dom'
import { Logo } from '@/components/common/logo'
import { Button } from '@/components/ui/button'
import { useAuth } from '@/contexts/auth-context'
import { cn } from '@/lib/utils'
import { DASHBOARD_PATH, NAV_ITEMS, ROLE_LABELS } from './nav-config'

interface SidebarProps {
  open: boolean
  onClose: () => void
}

export function Sidebar({ open, onClose }: SidebarProps) {
  const { role } = useAuth()
  if (!role) return null
  const items = NAV_ITEMS.filter((item) => item.roles.includes(role))

  return (
    <>
      <div
        aria-hidden="true"
        onClick={onClose}
        className={cn(
          'fixed inset-0 z-30 bg-foreground/30 transition-opacity lg:hidden',
          open ? 'opacity-100' : 'pointer-events-none opacity-0',
        )}
      />
      <aside
        id="app-sidebar"
        className={cn(
          'fixed inset-y-0 left-0 z-40 flex w-64 flex-col border-r border-sidebar-border bg-sidebar transition-transform lg:sticky lg:top-0 lg:h-dvh lg:translate-x-0',
          open ? 'translate-x-0' : '-translate-x-full',
        )}
      >
        <div className="flex h-16 items-center justify-between px-5">
          <Logo to={DASHBOARD_PATH[role]} />
          <Button variant="ghost" size="icon" className="lg:hidden" onClick={onClose}>
            <X aria-hidden="true" />
            <span className="sr-only">Close navigation</span>
          </Button>
        </div>

        <nav aria-label="Main" className="flex-1 overflow-y-auto px-3 py-2">
          <p className="px-3 pb-2 text-xs font-medium uppercase tracking-wide text-muted-foreground">
            {ROLE_LABELS[role]} workspace
          </p>
          <ul className="flex flex-col gap-0.5">
            {items.map(({ label, to, icon: Icon }) => (
              <li key={to}>
                <NavLink
                  to={to}
                  end
                  onClick={onClose}
                  className={({ isActive }) =>
                    cn(
                      'flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium text-sidebar-foreground transition-colors hover:bg-sidebar-accent hover:text-sidebar-accent-foreground',
                      isActive && 'bg-sidebar-accent text-sidebar-accent-foreground',
                    )
                  }
                >
                  <Icon className="size-4" aria-hidden="true" />
                  {label}
                </NavLink>
              </li>
            ))}
          </ul>
        </nav>

        <div className="m-3 flex items-start gap-3 rounded-lg bg-secondary p-3 text-xs text-secondary-foreground">
          <ShieldCheck className="size-4 shrink-0" aria-hidden="true" />
          <p className="text-pretty">
            Access is limited to your role. Health indicators are informational, not diagnoses.
          </p>
        </div>
      </aside>
    </>
  )
}
