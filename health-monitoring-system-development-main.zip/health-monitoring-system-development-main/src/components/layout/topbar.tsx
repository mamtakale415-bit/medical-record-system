import { Bell, LogOut, Menu } from 'lucide-react'
import { Link, useNavigate } from 'react-router-dom'
import { Button, buttonVariants } from '@/components/ui/button'
import { Select } from '@/components/ui/form-controls'
import { useAuth } from '@/contexts/auth-context'
import { signOut } from '@/services/auth'
import type { Role } from '@/types'
import { DASHBOARD_PATH, ROLE_LABELS } from './nav-config'

export function Topbar({ onMenuClick }: { onMenuClick: () => void }) {
  const { user, role, isPreview, setPreviewRole } = useAuth()
  const navigate = useNavigate()

  const initials = (user?.displayName ?? (role ? ROLE_LABELS[role] : 'U'))
    .split(' ')
    .map((part) => part[0])
    .join('')
    .slice(0, 2)
    .toUpperCase()

  async function handleSignOut() {
    if (!isPreview) await signOut()
    navigate('/login')
  }

  return (
    <header className="sticky top-0 z-20 flex h-16 items-center gap-3 border-b bg-card/90 px-4 backdrop-blur sm:px-6">
      <Button
        variant="ghost"
        size="icon"
        className="lg:hidden"
        onClick={onMenuClick}
        aria-controls="app-sidebar"
      >
        <Menu aria-hidden="true" />
        <span className="sr-only">Open navigation</span>
      </Button>

      {isPreview ? (
        <div className="flex items-center gap-2">
          <label htmlFor="preview-role" className="hidden text-xs font-medium text-muted-foreground sm:block">
            Layout preview as
          </label>
          <Select
            id="preview-role"
            value={role ?? 'patient'}
            onChange={(e) => {
              const next = e.target.value as Role
              setPreviewRole(next)
              navigate(DASHBOARD_PATH[next])
            }}
            className="h-8 w-32"
          >
            <option value="patient">Patient</option>
            <option value="doctor">Doctor</option>
            <option value="admin">Admin</option>
          </Select>
        </div>
      ) : null}

      <div className="ml-auto flex items-center gap-2">
        <Link
          to="/app/notifications"
          className={buttonVariants({ variant: 'ghost', size: 'icon' })}
        >
          <Bell aria-hidden="true" />
          <span className="sr-only">Notifications</span>
        </Link>
        <div className="flex items-center gap-2 border-l pl-3">
          <span
            aria-hidden="true"
            className="flex size-8 items-center justify-center rounded-full bg-accent text-xs font-semibold text-accent-foreground"
          >
            {initials}
          </span>
          <div className="hidden flex-col leading-tight sm:flex">
            <span className="text-sm font-medium">{user?.displayName ?? 'Not signed in'}</span>
            <span className="text-xs text-muted-foreground">{role ? ROLE_LABELS[role] : ''}</span>
          </div>
          <Button variant="ghost" size="icon" onClick={handleSignOut}>
            <LogOut aria-hidden="true" />
            <span className="sr-only">{isPreview ? 'Exit preview' : 'Sign out'}</span>
          </Button>
        </div>
      </div>
    </header>
  )
}
