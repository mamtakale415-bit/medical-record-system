import { onAuthStateChanged } from 'firebase/auth'
import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from 'react'
import { getFirebase, isFirebaseConfigured } from '@/lib/firebase'
import { fetchUserProfile } from '@/services/auth'
import type { Role, UserProfile } from '@/types'

type AuthStatus = 'loading' | 'signed-out' | 'signed-in' | 'preview'

interface AuthContextValue {
  status: AuthStatus
  user: UserProfile | null
  /** Role used for navigation: the real role, or the chosen layout-preview role. */
  role: Role | null
  isPreview: boolean
  setPreviewRole: (role: Role) => void
  profileError: string | null
}

const AuthContext = createContext<AuthContextValue | null>(null)

export function AuthProvider({ children }: { children: ReactNode }) {
  const [status, setStatus] = useState<AuthStatus>(isFirebaseConfigured ? 'loading' : 'preview')
  const [user, setUser] = useState<UserProfile | null>(null)
  const [previewRole, setPreviewRole] = useState<Role>('patient')
  const [profileError, setProfileError] = useState<string | null>(null)

  useEffect(() => {
    const firebase = getFirebase()
    if (!firebase) return
    return onAuthStateChanged(firebase.auth, async (firebaseUser) => {
      if (!firebaseUser) {
        setUser(null)
        setStatus('signed-out')
        return
      }
      try {
        const profile = await fetchUserProfile(firebaseUser.uid)
        setUser(profile)
        setProfileError(profile ? null : 'No user profile with a role was found for this account.')
        setStatus(profile ? 'signed-in' : 'signed-out')
      } catch (error) {
        setProfileError(error instanceof Error ? error.message : 'Could not load user profile.')
        setStatus('signed-out')
      }
    })
  }, [])

  const value = useMemo<AuthContextValue>(
    () => ({
      status,
      user,
      role: status === 'preview' ? previewRole : (user?.role ?? null),
      isPreview: status === 'preview',
      setPreviewRole,
      profileError,
    }),
    [status, user, previewRole, profileError],
  )

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (!context) throw new Error('useAuth must be used within AuthProvider')
  return context
}
