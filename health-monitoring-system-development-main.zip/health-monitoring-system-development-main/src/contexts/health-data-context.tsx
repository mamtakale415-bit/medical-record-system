import { createContext, useContext, useMemo, useState, type ReactNode } from 'react'
import { DEFAULT_REFERENCE_RANGES } from '@/lib/health'
import type { HealthReading, RangedVitalKey, ReferenceRange, ReferenceRanges } from '@/types'

/**
 * Session-only store for readings and reference ranges entered in this browser.
 * Nothing here is persisted; the Firestore-backed version replaces this provider
 * in the Firebase integration stage (patients/{uid}/readings and /settings/ranges).
 */
interface HealthDataContextValue {
  readings: HealthReading[]
  addReading: (reading: Omit<HealthReading, 'id'>) => void
  ranges: ReferenceRanges
  updateRange: (key: RangedVitalKey, range: ReferenceRange) => void
  resetRanges: () => void
}

const HealthDataContext = createContext<HealthDataContextValue | null>(null)

export function HealthDataProvider({ children }: { children: ReactNode }) {
  const [readings, setReadings] = useState<HealthReading[]>([])
  const [ranges, setRanges] = useState<ReferenceRanges>(DEFAULT_REFERENCE_RANGES)

  const value = useMemo<HealthDataContextValue>(
    () => ({
      readings,
      addReading: (reading) =>
        setReadings((prev) =>
          [...prev, { ...reading, id: crypto.randomUUID() }].sort(
            (a, b) => new Date(a.recordedAt).getTime() - new Date(b.recordedAt).getTime(),
          ),
        ),
      ranges,
      updateRange: (key, range) => setRanges((prev) => ({ ...prev, [key]: range })),
      resetRanges: () => setRanges(DEFAULT_REFERENCE_RANGES),
    }),
    [readings, ranges],
  )

  return <HealthDataContext.Provider value={value}>{children}</HealthDataContext.Provider>
}

export function useHealthData() {
  const context = useContext(HealthDataContext)
  if (!context) throw new Error('useHealthData must be used within HealthDataProvider')
  return context
}
