import type {
  IndicatorStatus,
  RangedVitalKey,
  ReferenceRange,
  ReferenceRanges,
  VitalKey,
} from '@/types'

export interface VitalMeta {
  key: VitalKey
  label: string
  shortLabel: string
  unit: string
  step: number
  min: number
  max: number
  chartColor: string
}

export const VITALS: Record<VitalKey, VitalMeta> = {
  heartRate: {
    key: 'heartRate',
    label: 'Heart rate',
    shortLabel: 'HR',
    unit: 'bpm',
    step: 1,
    min: 20,
    max: 250,
    chartColor: 'var(--chart-1)',
  },
  systolic: {
    key: 'systolic',
    label: 'Systolic pressure',
    shortLabel: 'SYS',
    unit: 'mmHg',
    step: 1,
    min: 50,
    max: 260,
    chartColor: 'var(--chart-4)',
  },
  diastolic: {
    key: 'diastolic',
    label: 'Diastolic pressure',
    shortLabel: 'DIA',
    unit: 'mmHg',
    step: 1,
    min: 30,
    max: 160,
    chartColor: 'var(--chart-3)',
  },
  glucose: {
    key: 'glucose',
    label: 'Blood glucose',
    shortLabel: 'GLU',
    unit: 'mg/dL',
    step: 1,
    min: 20,
    max: 600,
    chartColor: 'var(--chart-2)',
  },
  temperature: {
    key: 'temperature',
    label: 'Body temperature',
    shortLabel: 'TEMP',
    unit: '°C',
    step: 0.1,
    min: 30,
    max: 44,
    chartColor: 'var(--chart-5)',
  },
  spo2: {
    key: 'spo2',
    label: 'Oxygen saturation',
    shortLabel: 'SpO₂',
    unit: '%',
    step: 1,
    min: 50,
    max: 100,
    chartColor: 'var(--chart-1)',
  },
  weight: {
    key: 'weight',
    label: 'Weight',
    shortLabel: 'WT',
    unit: 'kg',
    step: 0.1,
    min: 1,
    max: 400,
    chartColor: 'var(--chart-4)',
  },
}

export const VITAL_KEYS = Object.keys(VITALS) as VitalKey[]

export const RANGED_VITAL_KEYS: RangedVitalKey[] = [
  'heartRate',
  'systolic',
  'diastolic',
  'glucose',
  'temperature',
  'spo2',
]

/**
 * General adult reference values used as editable starting points only.
 * Care teams should configure ranges appropriate to each patient.
 */
export const DEFAULT_REFERENCE_RANGES: ReferenceRanges = {
  heartRate: { normalMin: 60, normalMax: 100, warningMin: 50, warningMax: 120 },
  systolic: { normalMin: 90, normalMax: 120, warningMin: 85, warningMax: 140 },
  diastolic: { normalMin: 60, normalMax: 80, warningMin: 55, warningMax: 90 },
  glucose: { normalMin: 70, normalMax: 99, warningMin: 60, warningMax: 125 },
  temperature: { normalMin: 36.1, normalMax: 37.2, warningMin: 35.5, warningMax: 38 },
  spo2: { normalMin: 95, normalMax: 100, warningMin: 90, warningMax: 100 },
}

export function evaluateReading(value: number, range: ReferenceRange): IndicatorStatus {
  if (value >= range.normalMin && value <= range.normalMax) return 'normal'
  if (value >= range.warningMin && value <= range.warningMax) return 'warning'
  return 'critical'
}

export function validateRange(range: ReferenceRange): string | null {
  const values = Object.values(range)
  if (values.some((v) => Number.isNaN(v))) return 'All values must be numbers.'
  if (range.normalMin > range.normalMax) return 'Normal minimum must not exceed normal maximum.'
  if (range.warningMin > range.normalMin) return 'Warning minimum must be at or below normal minimum.'
  if (range.warningMax < range.normalMax) return 'Warning maximum must be at or above normal maximum.'
  return null
}

export const STATUS_LABELS: Record<IndicatorStatus, string> = {
  normal: 'Normal',
  warning: 'Warning',
  critical: 'Critical',
}

export const INDICATOR_DISCLAIMER =
  'Indicators compare readings with the configured reference ranges. They are not a diagnosis — consult a qualified clinician about any reading.'

export function formatDateTime(iso: string) {
  return new Date(iso).toLocaleString(undefined, {
    dateStyle: 'medium',
    timeStyle: 'short',
  })
}
