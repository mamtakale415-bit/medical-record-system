import { FileText, History, Stethoscope, UserPlus, Users } from 'lucide-react'
import { useState } from 'react'
import { BackendNotice } from '@/components/common/backend-notice'
import { DataTable, type Column } from '@/components/common/data-table'
import { EmptyState } from '@/components/common/empty-state'
import { PageHeader } from '@/components/common/page-header'
import { SearchFilterBar } from '@/components/common/search-filter-bar'
import { StatCard } from '@/components/common/stat-card'
import { ROLE_LABELS } from '@/components/layout/nav-config'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import type { ActivityLog, UserProfile } from '@/types'

const PENDING = 'Connects in the Firestore stage'

export function AdminDashboardPage() {
  const [search, setSearch] = useState('')
  const [roleFilter, setRoleFilter] = useState('all')
  const users: UserProfile[] = []
  const logs: ActivityLog[] = []

  const userColumns: Column<UserProfile>[] = [
    { header: 'Name', cell: (u) => <span className="font-medium">{u.displayName}</span> },
    { header: 'Email', cell: (u) => u.email },
    { header: 'Role', cell: (u) => <Badge variant="secondary">{ROLE_LABELS[u.role]}</Badge> },
    { header: 'Actions', cell: () => <Button variant="outline" size="sm">Manage</Button> },
  ]
  const logColumns: Column<ActivityLog>[] = [
    { header: 'Time', cell: (l) => l.createdAt },
    { header: 'Action', cell: (l) => l.action },
    { header: 'Target', cell: (l) => l.target },
  ]

  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        title="Admin dashboard"
        description="Platform overview, user management and activity across CareCloud."
        actions={<Button size="lg" className="px-4" disabled><UserPlus aria-hidden="true" />Invite doctor</Button>}
      />
      <BackendNotice feature="The admin overview" pendingIntegration />
      <div className="grid gap-4 sm:grid-cols-3">
        <StatCard label="Patients" value={null} icon={Users} hint={PENDING} />
        <StatCard label="Doctors" value={null} icon={Stethoscope} hint={PENDING} />
        <StatCard label="Medical records" value={null} icon={FileText} hint={PENDING} />
      </div>
      <Card>
        <CardHeader>
          <CardTitle>User management</CardTitle>
          <CardDescription>Assign roles and manage access. Role changes are restricted to administrators by security rules.</CardDescription>
        </CardHeader>
        <CardContent className="flex flex-col gap-4">
          <SearchFilterBar
            searchLabel="Search users by name or email"
            search={search}
            onSearchChange={setSearch}
            filterLabel="Filter by role"
            filter={roleFilter}
            onFilterChange={setRoleFilter}
            filterOptions={[
              { value: 'all', label: 'All roles' },
              { value: 'admin', label: 'Administrators' },
              { value: 'doctor', label: 'Doctors' },
              { value: 'patient', label: 'Patients' },
            ]}
          />
          <DataTable
            caption="Users"
            columns={userColumns}
            rows={users}
            getRowKey={(u) => u.uid}
            empty={<EmptyState icon={Users} title="No users to show" description="Registered users will appear here once Firestore is connected." />}
          />
        </CardContent>
      </Card>
      <Card>
        <CardHeader>
          <CardTitle>Activity logs</CardTitle>
          <CardDescription>Sign-ins, record changes and role updates.</CardDescription>
        </CardHeader>
        <CardContent>
          <DataTable
            caption="Activity logs"
            columns={logColumns}
            rows={logs}
            getRowKey={(l) => l.id}
            empty={<EmptyState icon={History} title="No activity recorded" description="Platform activity will be logged here." />}
          />
        </CardContent>
      </Card>
    </div>
  )
}
