import { CalendarClock } from 'lucide-react'
import { useState } from 'react'
import { BackendNotice } from '@/components/common/backend-notice'
import { DataTable, type Column } from '@/components/common/data-table'
import { EmptyState } from '@/components/common/empty-state'
import { PageHeader } from '@/components/common/page-header'
import { SearchFilterBar } from '@/components/common/search-filter-bar'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Field, Input, Select, Textarea } from '@/components/ui/form-controls'
import { useAuth } from '@/contexts/auth-context'
import { formatDateTime } from '@/lib/health'
import type { Appointment } from '@/types'

export function AppointmentsPage() {
  const { role } = useAuth()
  const [search, setSearch] = useState('')
  const [status, setStatus] = useState('all')
  const appointments: Appointment[] = []

  const columns: Column<Appointment>[] = [
    { header: 'Date', cell: (a) => formatDateTime(a.scheduledAt) },
    { header: 'Reason', cell: (a) => a.reason },
    { header: 'Mode', cell: (a) => (a.mode === 'video' ? 'Video' : 'In-person') },
    { header: 'Status', cell: (a) => <Badge variant="secondary">{a.status}</Badge> },
  ]

  return (
    <div className="flex flex-col gap-6">
      <PageHeader title="Appointments" description="Request, confirm and review consultations." />
      <BackendNotice feature="Appointments" pendingIntegration />
      <div className="grid gap-6 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle>Schedule</CardTitle>
          </CardHeader>
          <CardContent className="flex flex-col gap-4">
            <SearchFilterBar
              searchLabel="Search appointments"
              search={search}
              onSearchChange={setSearch}
              filterLabel="Filter by status"
              filter={status}
              onFilterChange={setStatus}
              filterOptions={[
                { value: 'all', label: 'All statuses' },
                { value: 'requested', label: 'Requested' },
                { value: 'confirmed', label: 'Confirmed' },
                { value: 'completed', label: 'Completed' },
                { value: 'cancelled', label: 'Cancelled' },
              ]}
            />
            <DataTable
              caption="Appointments"
              columns={columns}
              rows={appointments}
              getRowKey={(a) => a.id}
              empty={<EmptyState icon={CalendarClock} title="No appointments" description="Scheduled and requested appointments will appear here." />}
            />
          </CardContent>
        </Card>
        {role === 'patient' ? (
          <Card>
            <CardHeader>
              <CardTitle>Request an appointment</CardTitle>
              <CardDescription>Your doctor will confirm the time.</CardDescription>
            </CardHeader>
            <CardContent>
              <form className="flex flex-col gap-4" onSubmit={(e) => e.preventDefault()}>
                <Field id="appt-date" label="Preferred date and time">
                  <Input id="appt-date" type="datetime-local" />
                </Field>
                <Field id="appt-mode" label="Consultation mode">
                  <Select id="appt-mode">
                    <option value="in-person">In-person</option>
                    <option value="video">Video</option>
                  </Select>
                </Field>
                <Field id="appt-reason" label="Reason">
                  <Textarea id="appt-reason" maxLength={500} />
                </Field>
                <Button type="submit" size="lg" disabled>Send request</Button>
              </form>
            </CardContent>
          </Card>
        ) : (
          <Card>
            <CardHeader>
              <CardTitle>Pending requests</CardTitle>
              <CardDescription>Requests awaiting confirmation.</CardDescription>
            </CardHeader>
            <CardContent>
              <EmptyState icon={CalendarClock} title="No pending requests" description="New requests will appear here." />
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}
