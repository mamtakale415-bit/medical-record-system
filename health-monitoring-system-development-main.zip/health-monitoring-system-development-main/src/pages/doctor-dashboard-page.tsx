import { Activity, CalendarClock, FileText, Users } from 'lucide-react'
import { Link } from 'react-router-dom'
import { BackendNotice } from '@/components/common/backend-notice'
import { EmptyState } from '@/components/common/empty-state'
import { PageHeader } from '@/components/common/page-header'
import { StatCard } from '@/components/common/stat-card'
import { buttonVariants } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'

const PENDING = 'Connects in the Firestore stage'

export function DoctorDashboardPage() {
  return (
    <div className="flex flex-col gap-6">
      <PageHeader title="Doctor dashboard" description="Your assigned patients, upcoming appointments and latest health updates." />
      <BackendNotice feature="The doctor overview" pendingIntegration />
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard label="Assigned patients" value={null} icon={Users} hint={PENDING} />
        <StatCard label="Appointments today" value={null} icon={CalendarClock} hint={PENDING} />
        <StatCard label="Records updated this week" value={null} icon={FileText} hint={PENDING} />
        <StatCard label="Readings needing review" value={null} icon={Activity} hint={PENDING} />
      </div>
      <div className="grid gap-6 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Assigned patients</CardTitle>
            <CardDescription>Patients an administrator has assigned to you.</CardDescription>
          </CardHeader>
          <CardContent>
            <EmptyState icon={Users} title="No assigned patients" description="Assigned patients will be listed here." />
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>Upcoming appointments</CardTitle>
            <CardDescription>Confirmed and requested consultations.</CardDescription>
          </CardHeader>
          <CardContent>
            <EmptyState
              icon={CalendarClock}
              title="No upcoming appointments"
              description="Appointment requests from your patients appear here."
              action={<Link to="/app/appointments" className={buttonVariants({ variant: 'outline' })}>View appointments</Link>}
            />
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>Recent health updates</CardTitle>
            <CardDescription>New readings from your patients, including Warning and Critical indicators.</CardDescription>
          </CardHeader>
          <CardContent>
            <EmptyState icon={Activity} title="No new readings" description="Readings shared by your patients will appear here." />
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>Recent medical records</CardTitle>
            <CardDescription>Diagnoses, treatments and reports you recently updated.</CardDescription>
          </CardHeader>
          <CardContent>
            <EmptyState
              icon={FileText}
              title="No recent records"
              description="Records you create or update will be listed here."
              action={<Link to="/app/records" className={buttonVariants({ variant: 'outline' })}>Open records</Link>}
            />
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
