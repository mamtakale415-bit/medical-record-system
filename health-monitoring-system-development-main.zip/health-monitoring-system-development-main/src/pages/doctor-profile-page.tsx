import { BackendNotice } from '@/components/common/backend-notice'
import { PageHeader } from '@/components/common/page-header'
import { ProfileSection } from '@/components/common/profile-section'
import { Button } from '@/components/ui/button'
import { useAuth } from '@/contexts/auth-context'

export function DoctorProfilePage() {
  const { user } = useAuth()

  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        title="Doctor profile"
        description="Professional details shown to your patients and administrators."
        actions={<Button size="lg" className="px-4" disabled>Save changes</Button>}
      />
      <BackendNotice feature="Profile editing" pendingIntegration />
      <ProfileSection
        title="Professional details"
        fields={[
          { id: 'd-name', label: 'Full name', defaultValue: user?.displayName },
          { id: 'd-email', label: 'Email', type: 'email', defaultValue: user?.email },
          { id: 'd-specialty', label: 'Specialty' },
          { id: 'd-license', label: 'License number' },
          { id: 'd-experience', label: 'Years of experience', type: 'number' },
          { id: 'd-phone', label: 'Clinic phone', type: 'tel' },
          { id: 'd-bio', label: 'Bio', type: 'textarea', full: true },
        ]}
      />
      <ProfileSection
        title="Availability"
        description="Used when patients request appointments."
        fields={[
          { id: 'd-clinic', label: 'Clinic or hospital' },
          { id: 'd-mode', label: 'Consultation modes', type: 'select', options: ['In-person', 'Video', 'In-person and video'] },
          { id: 'd-hours', label: 'Working hours', full: true },
        ]}
      />
    </div>
  )
}
