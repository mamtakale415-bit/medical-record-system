import { Cpu, Info } from 'lucide-react'
import { useState } from 'react'
import { BackendNotice } from '@/components/common/backend-notice'
import { PageHeader } from '@/components/common/page-header'
import { ReadingEntryForm } from '@/components/health/reading-entry-form'
import { ReadingsTable } from '@/components/health/readings-table'
import { ReferenceRangeEditor } from '@/components/health/reference-range-editor'
import { VitalTrendChart } from '@/components/health/vital-trend-chart'
import { VitalsOverview } from '@/components/health/vitals-overview'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Select } from '@/components/ui/form-controls'
import { useAuth } from '@/contexts/auth-context'
import { useHealthData } from '@/contexts/health-data-context'
import { INDICATOR_DISCLAIMER } from '@/lib/health'
import type { ReadingSource, VitalKey } from '@/types'

const CHART_OPTIONS: { value: string; label: string; vitals: VitalKey[] }[] = [
  { value: 'heartRate', label: 'Heart rate', vitals: ['heartRate'] },
  { value: 'bp', label: 'Blood pressure', vitals: ['systolic', 'diastolic'] },
  { value: 'glucose', label: 'Blood glucose', vitals: ['glucose'] },
  { value: 'temperature', label: 'Body temperature', vitals: ['temperature'] },
  { value: 'spo2', label: 'Oxygen saturation', vitals: ['spo2'] },
  { value: 'weight', label: 'Weight', vitals: ['weight'] },
]

export function HealthMonitoringPage() {
  const { role } = useAuth()
  const { readings, ranges } = useHealthData()
  const [chart, setChart] = useState('heartRate')
  const [source, setSource] = useState<'all' | ReadingSource>('all')

  const option = CHART_OPTIONS.find((o) => o.value === chart) ?? CHART_OPTIONS[0]
  const filtered = source === 'all' ? readings : readings.filter((r) => r.source === source)
  const range = option.vitals.length === 1 && option.vitals[0] !== 'weight' ? ranges[option.vitals[0] as Exclude<VitalKey, 'weight'>] : undefined

  return (
    <div className="flex flex-col gap-6">
      <PageHeader title="Health monitoring" description="Track vital signs over time from manual entries and connected devices." />
      <BackendNotice feature="Health readings" pendingIntegration />
      <VitalsOverview />

      <Card>
        <CardHeader className="sm:flex-row sm:items-end sm:justify-between">
          <div className="flex flex-col gap-1">
            <CardTitle>Trends</CardTitle>
            <CardDescription>Tooltips show whether each point came from a manual entry or a connected device.</CardDescription>
          </div>
          <div className="flex flex-col gap-2 sm:flex-row">
            <label htmlFor="chart-vital" className="sr-only">Vital sign</label>
            <Select id="chart-vital" value={chart} onChange={(e) => setChart(e.target.value)} className="sm:w-48">
              {CHART_OPTIONS.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
            </Select>
            <label htmlFor="chart-source" className="sr-only">Reading source</label>
            <Select id="chart-source" value={source} onChange={(e) => setSource(e.target.value as typeof source)} className="sm:w-48">
              <option value="all">All sources</option>
              <option value="manual">Manual entries</option>
              <option value="device">Connected devices</option>
            </Select>
          </div>
        </CardHeader>
        <CardContent>
          <VitalTrendChart readings={filtered} vitals={option.vitals} range={range} />
        </CardContent>
      </Card>

      {role === 'patient' || role === 'doctor' ? <ReadingEntryForm /> : null}

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Cpu className="size-4 text-primary" aria-hidden="true" />
            Connected devices
          </CardTitle>
          <CardDescription>
            No devices are connected. Device integrations (for example wearables or Bluetooth monitors) will write readings tagged as connected-device data.
          </CardDescription>
        </CardHeader>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Reading history</CardTitle>
          <CardDescription>The indicator reflects the most out-of-range value in each reading.</CardDescription>
        </CardHeader>
        <CardContent>
          <ReadingsTable readings={filtered} ranges={ranges} />
        </CardContent>
      </Card>

      <ReferenceRangeEditor readOnly={role === 'patient'} />

      <p className="flex items-start gap-2 text-xs text-muted-foreground">
        <Info className="mt-0.5 size-3.5 shrink-0" aria-hidden="true" />
        {INDICATOR_DISCLAIMER}
      </p>
    </div>
  )
}
