import {
  Activity,
  BellRing,
  CalendarClock,
  FileText,
  Lock,
  ShieldCheck,
  Stethoscope,
  Upload,
  UserCog,
  UserRound,
} from 'lucide-react'
import { Link } from 'react-router-dom'
import { Logo } from '@/components/common/logo'
import { PublicHeader } from '@/components/layout/public-header'
import { buttonVariants } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import { INDICATOR_DISCLAIMER } from '@/lib/health'

const features = [
  { icon: Activity, title: 'Health monitoring', text: 'Chart heart rate, blood pressure, glucose, temperature, SpO₂ and weight with Normal, Warning and Critical indicators.' },
  { icon: FileText, title: 'Medical records', text: 'Keep medical history, diagnoses, treatments and prescriptions searchable in one place.' },
  { icon: Upload, title: 'Report uploads', text: 'Upload PDF and image reports to secure cloud storage, linked to the right patient.' },
  { icon: CalendarClock, title: 'Appointments', text: 'Request, confirm and track in-person or video consultations.' },
  { icon: BellRing, title: 'Notifications', text: 'Stay informed about appointments, new records and readings that need attention.' },
  { icon: ShieldCheck, title: 'Role-based access', text: 'Admins, doctors and patients each see only what their role permits.' },
]

const roles = [
  { icon: UserCog, title: 'Administrators', text: 'Manage users and roles, review platform activity and oversee records.' },
  { icon: Stethoscope, title: 'Doctors', text: 'Follow assigned patients, review health updates, and manage records and prescriptions.' },
  { icon: UserRound, title: 'Patients', text: 'Log readings, view trends, upload reports and manage appointments.' },
]

export function LandingPage() {
  return (
    <div className="flex min-h-dvh flex-col">
      <PublicHeader />
      <main className="flex-1">
        <section className="border-b bg-gradient-to-b from-secondary/60 to-background">
          <div className="mx-auto grid max-w-6xl items-center gap-12 px-4 py-16 sm:px-6 lg:grid-cols-2 lg:py-24">
            <div className="flex flex-col gap-6">
              <span className="w-fit rounded-full bg-accent px-3 py-1 text-xs font-medium text-accent-foreground">
                Cloud-based smart health monitoring
              </span>
              <h1 className="text-4xl font-semibold tracking-tight text-balance sm:text-5xl">
                Follow every vital sign, together with your care team.
              </h1>
              <p className="max-w-xl text-lg text-muted-foreground text-pretty">
                CareCloud brings patient readings, medical records, reports and appointments into one secure workspace for patients, doctors and administrators.
              </p>
              <div className="flex flex-wrap gap-3">
                <Link to="/register" className={buttonVariants({ size: 'lg', className: 'h-11 px-5' })}>
                  Register as a patient
                </Link>
                <Link to="/login" className={buttonVariants({ size: 'lg', variant: 'outline', className: 'h-11 px-5' })}>
                  Sign in
                </Link>
              </div>
            </div>
            <Card className="flex flex-col gap-4 p-6" aria-hidden="true">
              <div className="flex items-center justify-between">
                <p className="text-sm font-medium">How indicators work</p>
                <Activity className="size-4 text-primary" />
              </div>
              {[
                { label: 'Normal', desc: 'Within the configured normal range', cls: 'bg-success' },
                { label: 'Warning', desc: 'Outside normal, within warning range', cls: 'bg-warning' },
                { label: 'Critical', desc: 'Outside the warning range', cls: 'bg-destructive' },
              ].map((item) => (
                <div key={item.label} className="flex items-center gap-3 rounded-lg border p-3">
                  <span className={`size-2.5 rounded-full ${item.cls}`} />
                  <div>
                    <p className="text-sm font-medium">{item.label}</p>
                    <p className="text-xs text-muted-foreground">{item.desc}</p>
                  </div>
                </div>
              ))}
              <p className="text-xs text-muted-foreground text-pretty">{INDICATOR_DISCLAIMER}</p>
            </Card>
          </div>
        </section>

        <section id="features" className="mx-auto max-w-6xl scroll-mt-20 px-4 py-16 sm:px-6">
          <h2 className="text-2xl font-semibold tracking-tight">Everything in one place</h2>
          <p className="mt-2 max-w-2xl text-muted-foreground">Built for continuous care, from daily readings to clinical records.</p>
          <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {features.map(({ icon: Icon, title, text }) => (
              <Card key={title} className="flex flex-col gap-3 p-5">
                <span className="flex size-10 items-center justify-center rounded-lg bg-accent text-accent-foreground">
                  <Icon className="size-5" aria-hidden="true" />
                </span>
                <h3 className="font-semibold">{title}</h3>
                <p className="text-sm text-muted-foreground text-pretty">{text}</p>
              </Card>
            ))}
          </div>
        </section>

        <section id="roles" className="scroll-mt-20 border-y bg-secondary/40">
          <div className="mx-auto max-w-6xl px-4 py-16 sm:px-6">
            <h2 className="text-2xl font-semibold tracking-tight">Designed for every role</h2>
            <div className="mt-8 grid gap-4 md:grid-cols-3">
              {roles.map(({ icon: Icon, title, text }) => (
                <div key={title} className="flex flex-col gap-3 rounded-xl bg-card p-6 shadow-xs ring-1 ring-border">
                  <Icon className="size-6 text-primary" aria-hidden="true" />
                  <h3 className="font-semibold">{title}</h3>
                  <p className="text-sm text-muted-foreground">{text}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section id="security" className="mx-auto flex max-w-6xl scroll-mt-20 flex-col gap-4 px-4 py-16 sm:px-6 md:flex-row md:items-center">
          <span className="flex size-12 shrink-0 items-center justify-center rounded-xl bg-primary text-primary-foreground">
            <Lock className="size-5" aria-hidden="true" />
          </span>
          <div>
            <h2 className="text-xl font-semibold">Security by design</h2>
            <p className="mt-1 max-w-3xl text-muted-foreground text-pretty">
              Authentication runs on Firebase Authentication, and Cloud Firestore and Firebase Storage security rules restrict each record and file to the patient, their assigned doctors and administrators.
            </p>
          </div>
        </section>
      </main>
      <footer className="border-t">
        <div className="mx-auto flex max-w-6xl flex-col gap-2 px-4 py-6 text-sm text-muted-foreground sm:flex-row sm:items-center sm:justify-between sm:px-6">
          <Logo />
          <p>Health indicators are informational and are not a medical diagnosis.</p>
        </div>
      </footer>
    </div>
  )
}
