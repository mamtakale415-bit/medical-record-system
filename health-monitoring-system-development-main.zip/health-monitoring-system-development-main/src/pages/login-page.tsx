import { FirebaseError } from 'firebase/app'
import { useEffect, useState, type FormEvent } from 'react'
import { Link, useLocation, useNavigate } from 'react-router-dom'
import { BackendNotice } from '@/components/common/backend-notice'
import { FormAlert } from '@/components/common/form-alert'
import { AuthLayout } from '@/components/layout/auth-layout'
import { DASHBOARD_PATH } from '@/components/layout/nav-config'
import { Button } from '@/components/ui/button'
import { Field, Input } from '@/components/ui/form-controls'
import { useAuth } from '@/contexts/auth-context'
import { isFirebaseConfigured } from '@/lib/firebase'
import { signIn } from '@/services/auth'

function friendlyAuthError(error: unknown) {
  if (error instanceof FirebaseError) {
    if (['auth/invalid-credential', 'auth/wrong-password', 'auth/user-not-found'].includes(error.code)) {
      return 'Email or password is incorrect.'
    }
    if (error.code === 'auth/too-many-requests') return 'Too many attempts. Please wait and try again.'
  }
  return 'Sign in failed. Please try again.'
}

export function LoginPage() {
  const { status, role, profileError } = useAuth()
  const navigate = useNavigate()
  const location = useLocation()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState<string | null>(null)
  const [submitting, setSubmitting] = useState(false)

  useEffect(() => {
    if (status === 'signed-in' && role) {
      const from = (location.state as { from?: string } | null)?.from
      navigate(from ?? DASHBOARD_PATH[role], { replace: true })
    }
  }, [status, role, navigate, location.state])

  async function handleSubmit(event: FormEvent) {
    event.preventDefault()
    setError(null)
    setSubmitting(true)
    try {
      await signIn(email.trim(), password)
    } catch (err) {
      setError(friendlyAuthError(err))
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <AuthLayout title="Sign in" description="Access your CareCloud workspace.">
      <BackendNotice feature="Sign in" />
      <form onSubmit={handleSubmit} className="flex flex-col gap-4">
        <Field id="email" label="Email">
          <Input id="email" type="email" autoComplete="email" required value={email} onChange={(e) => setEmail(e.target.value)} />
        </Field>
        <Field id="password" label="Password">
          <Input id="password" type="password" autoComplete="current-password" required value={password} onChange={(e) => setPassword(e.target.value)} />
        </Field>
        {error || profileError ? <FormAlert tone="error" message={error ?? profileError ?? ''} /> : null}
        <Button type="submit" size="lg" className="h-10" disabled={!isFirebaseConfigured || submitting}>
          {submitting ? 'Signing in…' : 'Sign in'}
        </Button>
      </form>
      {!isFirebaseConfigured ? (
        <Link to="/app" className="text-center text-sm font-medium text-primary hover:underline">
          Explore the layout preview instead
        </Link>
      ) : null}
      <p className="text-center text-sm text-muted-foreground">
        New patient?{' '}
        <Link to="/register" className="font-medium text-primary hover:underline">Create an account</Link>
      </p>
    </AuthLayout>
  )
}
