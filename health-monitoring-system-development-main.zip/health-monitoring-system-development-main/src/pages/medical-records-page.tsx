import { FileText, Plus } from 'lucide-react'
import { useMemo, useState } from 'react'
import { Link } from 'react-router-dom'
import { BackendNotice } from '@/components/common/backend-notice'
import { DataTable, type Column } from '@/components/common/data-table'
import { EmptyState } from '@/components/common/empty-state'
import { PageHeader } from '@/components/common/page-header'
import { SearchFilterBar } from '@/components/common/search-filter-bar'
import { Badge } from '@/components/ui/badge'
import { Button, buttonVariants } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { useAuth } from '@/contexts/auth-context'
import { formatDateTime } from '@/lib/health'
import type { MedicalRecord } from '@/types'

const TYPE_LABELS: Record<MedicalRecord['type'], string> = {
  history: 'Medical history',
  diagnosis: 'Diagnosis',
  treatment: 'Treatment',
  lab: 'Lab result',
  imaging: 'Imaging',
}

const TABS = [
  { value: 'all', label: 'All records' },
  ...Object.entries(TYPE_LABELS).map(([value, label]) => ({ value, label })),
]

export function MedicalRecordsPage() {
  const { role } = useAuth()
  const [search, setSearch] = useState('')
  const [type, setType] = useState('all')
  const records: MedicalRecord[] = []

  const visible = useMemo(() => {
    const q = search.trim().toLowerCase()
    return records.filter(
      (r) => (type === 'all' || r.type === type) && (!q || `${r.title} ${r.description}`.toLowerCase().includes(q)),
    )
  }, [records, search, type])

  const columns: Column<MedicalRecord>[] = [
    { header: 'Title', cell: (r) => <span className="font-medium">{r.title}</span> },
    { header: 'Type', cell: (r) => <Badge variant="secondary">{TYPE_LABELS[r.type]}</Badge> },
    { header: 'Recorded by', cell: (r) => r.recordedBy },
    { header: 'Date', cell: (r) => formatDateTime(r.recordedAt) },
  ]

  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        title="Medical records"
        description="Medical history, diagnoses, treatments and test results."
        actions={
          <>
            <Link to="/app/prescriptions" className={buttonVariants({ variant: 'outline', size: 'lg', className: 'px-4' })}>
              Prescriptions
            </Link>
            {role === 'doctor' ? (
              <Button size="lg" className="px-4" disabled>
                <Plus aria-hidden="true" />
                New record
              </Button>
            ) : null}
          </>
        }
      />
      <BackendNotice feature="Medical records" pendingIntegration />
      <div role="tablist" aria-label="Record type" className="flex gap-1 overflow-x-auto rounded-lg bg-muted p-1">
        {TABS.map((tab) => (
          <button
            key={tab.value}
            role="tab"
            aria-selected={type === tab.value}
            onClick={() => setType(tab.value)}
            className="whitespace-nowrap rounded-md px-3 py-1.5 text-sm font-medium text-muted-foreground transition hover:text-foreground aria-selected:bg-card aria-selected:text-foreground aria-selected:shadow-xs"
          >
            {tab.label}
          </button>
        ))}
      </div>
      <Card>
        <CardContent className="flex flex-col gap-4 pt-6">
          <SearchFilterBar searchLabel="Search records by title or description" search={search} onSearchChange={setSearch} />
          <DataTable
            caption="Medical records"
            columns={columns}
            rows={visible}
            getRowKey={(r) => r.id}
            empty={
              <EmptyState
                icon={FileText}
                title="No medical records"
                description="Records added by your care team, and uploaded reports, will appear here."
                action={<Link to="/app/reports/upload" className={buttonVariants({ variant: 'outline' })}>Upload a report</Link>}
              />
            }
          />
        </CardContent>
      </Card>
    </div>
  )
}
