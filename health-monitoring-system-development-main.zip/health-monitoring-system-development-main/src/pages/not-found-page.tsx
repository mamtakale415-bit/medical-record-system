import { Compass } from 'lucide-react'
import { Link } from 'react-router-dom'
import { EmptyState } from '@/components/common/empty-state'
import { buttonVariants } from '@/components/ui/button'

export function NotFoundPage() {
  return (
    <main className="flex min-h-dvh items-center justify-center p-6">
      <EmptyState
        icon={Compass}
        title="Page not found"
        description="The page you're looking for doesn't exist or has moved."
        action={<Link to="/" className={buttonVariants()}>Go home</Link>}
      />
    </main>
  )
}
