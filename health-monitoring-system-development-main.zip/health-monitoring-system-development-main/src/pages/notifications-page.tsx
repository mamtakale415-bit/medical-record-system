import { Bell } from 'lucide-react'
import { useState } from 'react'
import { BackendNotice } from '@/components/common/backend-notice'
import { EmptyState } from '@/components/common/empty-state'
import { PageHeader } from '@/components/common/page-header'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import type { AppNotification } from '@/types'

const FILTERS = [
  { value: 'all', label: 'All' },
  { value: 'unread', label: 'Unread' },
  { value: 'appointment', label: 'Appointments' },
  { value: 'reading', label: 'Readings' },
  { value: 'record', label: 'Records' },
  { value: 'system', label: 'System' },
]

export function NotificationsPage() {
  const [filter, setFilter] = useState('all')
  const notifications: AppNotification[] = []
  const visible = notifications.filter((n) =>
    filter === 'all' ? true : filter === 'unread' ? !n.read : n.category === filter,
  )

  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        title="Notifications"
        description="Updates about appointments, records and readings."
        actions={<Button variant="outline" size="lg" className="px-4" disabled={notifications.length === 0}>Mark all as read</Button>}
      />
      <BackendNotice feature="Notifications" pendingIntegration />
      <div className="flex flex-wrap gap-2" role="group" aria-label="Filter notifications">
        {FILTERS.map((f) => (
          <Button key={f.value} variant={filter === f.value ? 'default' : 'outline'} aria-pressed={filter === f.value} onClick={() => setFilter(f.value)}>
            {f.label}
          </Button>
        ))}
      </div>
      <Card>
        <CardContent className="pt-6">
          {visible.length === 0 ? (
            <EmptyState icon={Bell} title="You're all caught up" description="New notifications will appear here." />
          ) : (
            <ul className="divide-y">
              {visible.map((n) => (
                <li key={n.id} className="flex flex-col gap-1 py-3">
                  <p className="font-medium">{n.title}</p>
                  <p className="text-sm text-muted-foreground">{n.body}</p>
                </li>
              ))}
            </ul>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
