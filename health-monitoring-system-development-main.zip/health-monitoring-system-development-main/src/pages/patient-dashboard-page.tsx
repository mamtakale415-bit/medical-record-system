import { CalendarClock, Info, Pill, Plus } from 'lucide-react'
import { Link } from 'react-router-dom'
import { BackendNotice } from '@/components/common/backend-notice'
import { EmptyState } from '@/components/common/empty-state'
import { PageHeader } from '@/components/common/page-header'
import { VitalTrendChart } from '@/components/health/vital-trend-chart'
import { VitalsOverview } from '@/components/health/vitals-overview'
import { buttonVariants } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { useHealthData } from '@/contexts/health-data-context'
import { INDICATOR_DISCLAIMER } from '@/lib/health'

export function PatientDashboardPage() {
  const { readings, ranges } = useHealthData()

  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        title="Health overview"
        description="Your latest vital signs and how they compare with your reference ranges."
        actions={
          <Link to="/app/monitoring" className={buttonVariants({ size: 'lg', className: 'px-4' })}>
            <Plus aria-hidden="true" />
            Add reading
          </Link>
        }
      />
      <BackendNotice feature="Health readings" pendingIntegration />
      <VitalsOverview />
      <p className="flex items-start gap-2 text-xs text-muted-foreground">
        <Info className="mt-0.5 size-3.5 shrink-0" aria-hidden="true" />
        {INDICATOR_DISCLAIMER}
      </p>
      <Card>
        <CardHeader>
          <CardTitle>Heart rate trend</CardTitle>
          <CardDescription>Shaded band shows your configured normal range.</CardDescription>
        </CardHeader>
        <CardContent>
          <VitalTrendChart readings={readings} vitals={['heartRate']} range={ranges.heartRate} />
        </CardContent>
      </Card>
      <div className="grid gap-6 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Upcoming appointments</CardTitle>
          </CardHeader>
          <CardContent>
            <EmptyState
              icon={CalendarClock}
              title="No upcoming appointments"
              description="Request a consultation with your doctor."
              action={<Link to="/app/appointments" className={buttonVariants({ variant: 'outline' })}>Request appointment</Link>}
            />
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>Active prescriptions</CardTitle>
          </CardHeader>
          <CardContent>
            <EmptyState icon={Pill} title="No active prescriptions" description="Prescriptions from your doctor will appear here." />
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
