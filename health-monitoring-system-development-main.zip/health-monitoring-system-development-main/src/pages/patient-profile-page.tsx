import { BackendNotice } from '@/components/common/backend-notice'
import { PageHeader } from '@/components/common/page-header'
import { ProfileSection } from '@/components/common/profile-section'
import { Button } from '@/components/ui/button'
import { useAuth } from '@/contexts/auth-context'

export function PatientProfilePage() {
  const { user } = useAuth()

  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        title="Patient profile"
        description="Personal, contact and medical background shared with your care team."
        actions={<Button size="lg" className="px-4" disabled>Save changes</Button>}
      />
      <BackendNotice feature="Profile editing" pendingIntegration />
      <ProfileSection
        title="Personal details"
        fields={[
          { id: 'p-name', label: 'Full name', defaultValue: user?.displayName },
          { id: 'p-email', label: 'Email', type: 'email', defaultValue: user?.email },
          { id: 'p-dob', label: 'Date of birth', type: 'date' },
          { id: 'p-gender', label: 'Gender', type: 'select', options: ['Female', 'Male', 'Other'] },
          { id: 'p-phone', label: 'Phone', type: 'tel' },
          { id: 'p-address', label: 'Address' },
        ]}
      />
      <ProfileSection
        title="Medical background"
        description="Helps your doctors interpret readings. Visible only to you, your assigned doctors and administrators."
        fields={[
          { id: 'p-blood', label: 'Blood type', type: 'select', options: ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'] },
          { id: 'p-height', label: 'Height (cm)', type: 'number' },
          { id: 'p-allergies', label: 'Allergies', type: 'textarea', full: true },
          { id: 'p-conditions', label: 'Chronic conditions', type: 'textarea', full: true },
        ]}
      />
      <ProfileSection
        title="Emergency contact"
        fields={[
          { id: 'p-ec-name', label: 'Contact name' },
          { id: 'p-ec-relation', label: 'Relationship' },
          { id: 'p-ec-phone', label: 'Phone', type: 'tel' },
        ]}
      />
    </div>
  )
}
