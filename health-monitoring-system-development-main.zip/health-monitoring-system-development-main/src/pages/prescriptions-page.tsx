import { Pill, Plus } from 'lucide-react'
import { useState } from 'react'
import { BackendNotice } from '@/components/common/backend-notice'
import { DataTable, type Column } from '@/components/common/data-table'
import { EmptyState } from '@/components/common/empty-state'
import { PageHeader } from '@/components/common/page-header'
import { SearchFilterBar } from '@/components/common/search-filter-bar'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { useAuth } from '@/contexts/auth-context'
import type { Prescription } from '@/types'

export function PrescriptionsPage() {
  const { role } = useAuth()
  const [search, setSearch] = useState('')
  const [status, setStatus] = useState('all')
  const prescriptions: Prescription[] = []

  const columns: Column<Prescription>[] = [
    { header: 'Medication', cell: (p) => <span className="font-medium">{p.medication}</span> },
    { header: 'Dosage', cell: (p) => p.dosage },
    { header: 'Frequency', cell: (p) => p.frequency },
    { header: 'Start', cell: (p) => p.startDate },
    { header: 'End', cell: (p) => p.endDate ?? 'Ongoing' },
    { header: 'Status', cell: (p) => <Badge variant={p.status === 'active' ? 'success' : 'outline'}>{p.status}</Badge> },
  ]

  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        title="Prescriptions"
        description="Medications prescribed by the care team."
        actions={
          role === 'doctor' ? (
            <Button size="lg" className="px-4" disabled>
              <Plus aria-hidden="true" />
              New prescription
            </Button>
          ) : null
        }
      />
      <BackendNotice feature="Prescriptions" pendingIntegration />
      <Card>
        <CardContent className="flex flex-col gap-4 pt-6">
          <SearchFilterBar
            searchLabel="Search by medication"
            search={search}
            onSearchChange={setSearch}
            filterLabel="Filter by status"
            filter={status}
            onFilterChange={setStatus}
            filterOptions={[
              { value: 'all', label: 'All statuses' },
              { value: 'active', label: 'Active' },
              { value: 'completed', label: 'Completed' },
              { value: 'cancelled', label: 'Cancelled' },
            ]}
          />
          <DataTable
            caption="Prescriptions"
            columns={columns}
            rows={prescriptions}
            getRowKey={(p) => p.id}
            empty={<EmptyState icon={Pill} title="No prescriptions" description="Prescriptions issued by a doctor will be listed here." />}
          />
        </CardContent>
      </Card>
    </div>
  )
}
