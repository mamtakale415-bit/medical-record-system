import { FirebaseError } from 'firebase/app'
import { useState, type FormEvent } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { BackendNotice } from '@/components/common/backend-notice'
import { FormAlert } from '@/components/common/form-alert'
import { AuthLayout } from '@/components/layout/auth-layout'
import { Button } from '@/components/ui/button'
import { Field, Input, Select } from '@/components/ui/form-controls'
import { isFirebaseConfigured } from '@/lib/firebase'
import { registerPatient } from '@/services/auth'

const initial = { displayName: '', email: '', password: '', confirm: '', dateOfBirth: '', phone: '', gender: '' }

export function RegisterPage() {
  const navigate = useNavigate()
  const [form, setForm] = useState(initial)
  const [consent, setConsent] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [submitting, setSubmitting] = useState(false)
  const set = (key: keyof typeof initial) => (e: { target: { value: string } }) =>
    setForm((prev) => ({ ...prev, [key]: e.target.value }))

  async function handleSubmit(event: FormEvent) {
    event.preventDefault()
    setError(null)
    if (form.displayName.trim().length < 2) return setError('Please enter your full name.')
    if (form.password.length < 8) return setError('Password must be at least 8 characters.')
    if (form.password !== form.confirm) return setError('Passwords do not match.')
    if (!form.dateOfBirth || new Date(form.dateOfBirth) > new Date()) return setError('Enter a valid date of birth.')
    if (!consent) return setError('Please accept the data processing terms to continue.')

    setSubmitting(true)
    try {
      await registerPatient({
        displayName: form.displayName.trim(),
        email: form.email.trim(),
        password: form.password,
        dateOfBirth: form.dateOfBirth,
        phone: form.phone.trim(),
        gender: form.gender,
      })
      navigate('/app/patient', { replace: true })
    } catch (err) {
      setError(
        err instanceof FirebaseError && err.code === 'auth/email-already-in-use'
          ? 'An account with this email already exists.'
          : 'Registration failed. Please try again.',
      )
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <AuthLayout title="Patient registration" description="Create your account to start tracking your health with your care team.">
      <BackendNotice feature="Registration" />
      <form onSubmit={handleSubmit} className="flex flex-col gap-4">
        <Field id="name" label="Full name">
          <Input id="name" autoComplete="name" required value={form.displayName} onChange={set('displayName')} />
        </Field>
        <Field id="reg-email" label="Email">
          <Input id="reg-email" type="email" autoComplete="email" required value={form.email} onChange={set('email')} />
        </Field>
        <div className="grid gap-4 sm:grid-cols-2">
          <Field id="dob" label="Date of birth">
            <Input id="dob" type="date" required value={form.dateOfBirth} onChange={set('dateOfBirth')} />
          </Field>
          <Field id="gender" label="Gender">
            <Select id="gender" value={form.gender} onChange={set('gender')}>
              <option value="">Prefer not to say</option>
              <option value="female">Female</option>
              <option value="male">Male</option>
              <option value="other">Other</option>
            </Select>
          </Field>
        </div>
        <Field id="phone" label="Phone">
          <Input id="phone" type="tel" autoComplete="tel" value={form.phone} onChange={set('phone')} />
        </Field>
        <div className="grid gap-4 sm:grid-cols-2">
          <Field id="reg-password" label="Password" hint="At least 8 characters">
            <Input id="reg-password" type="password" autoComplete="new-password" required value={form.password} onChange={set('password')} />
          </Field>
          <Field id="confirm" label="Confirm password">
            <Input id="confirm" type="password" autoComplete="new-password" required value={form.confirm} onChange={set('confirm')} />
          </Field>
        </div>
        <label className="flex items-start gap-2 text-sm text-muted-foreground">
          <input type="checkbox" className="mt-1 size-4 accent-primary" checked={consent} onChange={(e) => setConsent(e.target.checked)} />
          I agree that my health data is stored securely and shared only with my assigned care team and administrators.
        </label>
        {error ? <FormAlert tone="error" message={error} /> : null}
        <Button type="submit" size="lg" className="h-10" disabled={!isFirebaseConfigured || submitting}>
          {submitting ? 'Creating account…' : 'Create account'}
        </Button>
      </form>
      <p className="text-center text-sm text-muted-foreground">
        Already registered?{' '}
        <Link to="/login" className="font-medium text-primary hover:underline">Sign in</Link>
      </p>
    </AuthLayout>
  )
}
