import { CheckCircle2, CloudOff } from 'lucide-react'
import { BackendNotice } from '@/components/common/backend-notice'
import { PageHeader } from '@/components/common/page-header'
import { ReferenceRangeEditor } from '@/components/health/reference-range-editor'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Field, Input } from '@/components/ui/form-controls'
import { useAuth } from '@/contexts/auth-context'
import { isFirebaseConfigured } from '@/lib/firebase'

const NOTIFICATION_PREFS = [
  { id: 'n-appointments', label: 'Appointment updates' },
  { id: 'n-readings', label: 'Warning and Critical readings' },
  { id: 'n-records', label: 'New records and reports' },
  { id: 'n-email', label: 'Send copies by email' },
]

export function SettingsPage() {
  const { role } = useAuth()

  return (
    <div className="flex flex-col gap-6">
      <PageHeader title="Settings" description="Account security, notification preferences and system status." />
      <BackendNotice feature="Settings" pendingIntegration />
      <div className="grid gap-6 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Change password</CardTitle>
          </CardHeader>
          <CardContent>
            <form className="flex flex-col gap-4" onSubmit={(e) => e.preventDefault()}>
              <Field id="s-current" label="Current password">
                <Input id="s-current" type="password" autoComplete="current-password" />
              </Field>
              <Field id="s-new" label="New password" hint="At least 8 characters">
                <Input id="s-new" type="password" autoComplete="new-password" />
              </Field>
              <div>
                <Button type="submit" size="lg" className="px-4" disabled>Update password</Button>
              </div>
            </form>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>Notifications</CardTitle>
            <CardDescription>Choose what you want to be notified about.</CardDescription>
          </CardHeader>
          <CardContent className="flex flex-col gap-3">
            {NOTIFICATION_PREFS.map((p) => (
              <label key={p.id} htmlFor={p.id} className="flex items-center justify-between gap-4 rounded-lg border p-3 text-sm">
                {p.label}
                <input id={p.id} type="checkbox" defaultChecked className="size-4 accent-primary" />
              </label>
            ))}
          </CardContent>
        </Card>
      </div>
      <Card>
        <CardHeader>
          <CardTitle>Backend status</CardTitle>
          <CardDescription>Status of the Firebase services this app depends on.</CardDescription>
        </CardHeader>
        <CardContent className="grid gap-3 sm:grid-cols-3">
          {['Firebase Authentication', 'Cloud Firestore', 'Firebase Storage'].map((name) => (
            <div key={name} className="flex items-center gap-2 rounded-lg border p-3 text-sm">
              {isFirebaseConfigured ? (
                <CheckCircle2 className="size-4 text-success" aria-hidden="true" />
              ) : (
                <CloudOff className="size-4 text-muted-foreground" aria-hidden="true" />
              )}
              <span className="font-medium">{name}</span>
              <span className="ml-auto text-xs text-muted-foreground">{isFirebaseConfigured ? 'Configured' : 'Not configured'}</span>
            </div>
          ))}
        </CardContent>
      </Card>
      {role === 'doctor' || role === 'admin' ? <ReferenceRangeEditor /> : null}
    </div>
  )
}
