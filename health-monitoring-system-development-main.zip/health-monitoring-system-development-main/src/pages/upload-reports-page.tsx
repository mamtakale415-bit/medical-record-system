import { FileImage, FileText, UploadCloud, X } from 'lucide-react'
import { useRef, useState, type DragEvent, type FormEvent } from 'react'
import { BackendNotice } from '@/components/common/backend-notice'
import { FormAlert } from '@/components/common/form-alert'
import { PageHeader } from '@/components/common/page-header'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Field, Input, Select } from '@/components/ui/form-controls'
import { useAuth } from '@/contexts/auth-context'
import { isFirebaseConfigured } from '@/lib/firebase'
import { ACCEPTED_REPORT_TYPES, uploadReport, validateReportFile } from '@/services/reports'

const CATEGORIES = ['Lab result', 'Imaging', 'Discharge summary', 'Referral', 'Other']

function formatSize(bytes: number) {
  return bytes < 1024 * 1024 ? `${(bytes / 1024).toFixed(0)} KB` : `${(bytes / 1024 / 1024).toFixed(1)} MB`
}

export function UploadReportsPage() {
  const { user, role, isPreview } = useAuth()
  const inputRef = useRef<HTMLInputElement>(null)
  const [file, setFile] = useState<File | null>(null)
  const [category, setCategory] = useState(CATEGORIES[0])
  const [patientId, setPatientId] = useState('')
  const [dragging, setDragging] = useState(false)
  const [progress, setProgress] = useState<number | null>(null)
  const [message, setMessage] = useState<{ tone: 'error' | 'success'; text: string } | null>(null)

  const canUpload = isFirebaseConfigured && !isPreview && !!user

  function pick(selected: File | undefined) {
    if (!selected) return
    const error = validateReportFile(selected)
    setMessage(error ? { tone: 'error', text: error } : null)
    setFile(error ? null : selected)
  }

  function onDrop(e: DragEvent) {
    e.preventDefault()
    setDragging(false)
    pick(e.dataTransfer.files[0])
  }

  async function handleSubmit(e: FormEvent) {
    e.preventDefault()
    if (!file || !user) return
    const target = role === 'patient' ? user.uid : patientId.trim()
    if (!target) return setMessage({ tone: 'error', text: 'Enter the patient ID for this report.' })
    setMessage(null)
    setProgress(0)
    try {
      await uploadReport({ patientId: target, uploadedBy: user.uid, category, file, onProgress: setProgress })
      setMessage({ tone: 'success', text: `${file.name} uploaded.` })
      setFile(null)
    } catch {
      setMessage({ tone: 'error', text: 'Upload failed. Check your permissions and try again.' })
    } finally {
      setProgress(null)
    }
  }

  const FileIcon = file?.type === 'application/pdf' ? FileText : FileImage

  return (
    <div className="flex flex-col gap-6">
      <PageHeader title="Upload reports" description="Attach PDF or image reports to a patient's medical record." />
      <BackendNotice feature="Report uploads" />
      <Card>
        <CardHeader>
          <CardTitle>New report</CardTitle>
          <CardDescription>PDF, PNG, JPEG or WebP, up to 10 MB. Files are stored in Firebase Storage under the patient's folder.</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="flex flex-col gap-4">
            <div
              onDragOver={(e) => {
                e.preventDefault()
                setDragging(true)
              }}
              onDragLeave={() => setDragging(false)}
              onDrop={onDrop}
              className={`flex flex-col items-center gap-3 rounded-xl border-2 border-dashed px-6 py-10 text-center transition ${dragging ? 'border-primary bg-primary/5' : 'border-border bg-muted/30'}`}
            >
              <UploadCloud className="size-8 text-primary" aria-hidden="true" />
              <p className="text-sm">
                <span className="font-medium">Drag and drop a file</span> or
              </p>
              <Button type="button" variant="outline" onClick={() => inputRef.current?.click()}>Browse files</Button>
              <input
                ref={inputRef}
                type="file"
                accept={ACCEPTED_REPORT_TYPES.join(',')}
                className="sr-only"
                aria-label="Choose report file"
                onChange={(e) => pick(e.target.files?.[0])}
              />
            </div>
            {file ? (
              <div className="flex items-center gap-3 rounded-lg border p-3">
                <FileIcon className="size-5 text-primary" aria-hidden="true" />
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-medium">{file.name}</p>
                  <p className="text-xs text-muted-foreground">{formatSize(file.size)}</p>
                </div>
                <Button type="button" variant="ghost" size="icon" aria-label="Remove file" onClick={() => setFile(null)}>
                  <X />
                </Button>
              </div>
            ) : null}
            <div className="grid gap-4 sm:grid-cols-2">
              <Field id="category" label="Category">
                <Select id="category" value={category} onChange={(e) => setCategory(e.target.value)}>
                  {CATEGORIES.map((c) => <option key={c}>{c}</option>)}
                </Select>
              </Field>
              {role !== 'patient' ? (
                <Field id="patient-id" label="Patient ID" hint="The patient must be assigned to you.">
                  <Input id="patient-id" value={patientId} onChange={(e) => setPatientId(e.target.value)} />
                </Field>
              ) : null}
            </div>
            {progress !== null ? (
              <div className="flex flex-col gap-1">
                <div className="h-2 overflow-hidden rounded-full bg-muted" role="progressbar" aria-valuenow={progress} aria-valuemin={0} aria-valuemax={100} aria-label="Upload progress">
                  <div className="h-full bg-primary transition-all" style={{ width: `${progress}%` }} />
                </div>
                <p className="text-xs text-muted-foreground">{progress}%</p>
              </div>
            ) : null}
            {message ? <FormAlert tone={message.tone} message={message.text} /> : null}
            <div>
              <Button type="submit" size="lg" className="px-4" disabled={!canUpload || !file || progress !== null}>
                Upload report
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  )
}
