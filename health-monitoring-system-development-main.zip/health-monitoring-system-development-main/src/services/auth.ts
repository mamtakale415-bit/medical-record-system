import {
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signOut as firebaseSignOut,
  updateProfile,
} from 'firebase/auth'
import { doc, getDoc, serverTimestamp, setDoc } from 'firebase/firestore'
import { requireFirebase } from '@/lib/firebase'
import type { Role, UserProfile } from '@/types'

export interface PatientRegistration {
  displayName: string
  email: string
  password: string
  dateOfBirth: string
  phone: string
  gender: string
}

export async function signIn(email: string, password: string) {
  const { auth } = requireFirebase()
  await signInWithEmailAndPassword(auth, email, password)
}

/**
 * Self-registration always creates a patient. Doctor and admin roles must be
 * granted by an administrator — firestore.rules rejects any other self-assigned role.
 */
export async function registerPatient(data: PatientRegistration) {
  const { auth, db } = requireFirebase()
  const credential = await createUserWithEmailAndPassword(auth, data.email, data.password)
  const { uid } = credential.user
  await updateProfile(credential.user, { displayName: data.displayName })
  await setDoc(doc(db, 'users', uid), {
    email: data.email,
    displayName: data.displayName,
    role: 'patient' satisfies Role,
    createdAt: serverTimestamp(),
  })
  await setDoc(doc(db, 'patients', uid), {
    displayName: data.displayName,
    dateOfBirth: data.dateOfBirth,
    phone: data.phone,
    gender: data.gender,
    assignedDoctorIds: [],
    createdAt: serverTimestamp(),
  })
}

export async function signOut() {
  const { auth } = requireFirebase()
  await firebaseSignOut(auth)
}

export async function fetchUserProfile(uid: string): Promise<UserProfile | null> {
  const { db } = requireFirebase()
  const snapshot = await getDoc(doc(db, 'users', uid))
  if (!snapshot.exists()) return null
  const data = snapshot.data()
  return {
    uid,
    email: data.email,
    displayName: data.displayName,
    role: data.role as Role,
  }
}
