import { addDoc, collection, serverTimestamp } from 'firebase/firestore'
import { ref, uploadBytesResumable } from 'firebase/storage'
import { requireFirebase } from '@/lib/firebase'

export const ACCEPTED_REPORT_TYPES = ['application/pdf', 'image/png', 'image/jpeg', 'image/webp']
export const MAX_REPORT_BYTES = 10 * 1024 * 1024

export function validateReportFile(file: File): string | null {
  if (!ACCEPTED_REPORT_TYPES.includes(file.type)) return 'Only PDF, PNG, JPEG or WebP files are accepted.'
  if (file.size > MAX_REPORT_BYTES) return 'Files must be 10 MB or smaller.'
  return null
}

interface UploadOptions {
  patientId: string
  uploadedBy: string
  category: string
  file: File
  onProgress?: (percent: number) => void
}

export async function uploadReport({ patientId, uploadedBy, category, file, onProgress }: UploadOptions) {
  const { db, storage } = requireFirebase()
  const safeName = file.name.replace(/[^\w.-]+/g, '_')
  const storagePath = `reports/${patientId}/${Date.now()}-${safeName}`
  const task = uploadBytesResumable(ref(storage, storagePath), file, { contentType: file.type })

  await new Promise<void>((resolve, reject) => {
    task.on(
      'state_changed',
      (snap) => onProgress?.(Math.round((snap.bytesTransferred / snap.totalBytes) * 100)),
      reject,
      () => resolve(),
    )
  })

  await addDoc(collection(db, 'patients', patientId, 'reports'), {
    patientId,
    fileName: file.name,
    contentType: file.type,
    size: file.size,
    storagePath,
    category,
    uploadedBy,
    uploadedAt: serverTimestamp(),
  })
}
