export type Role = 'admin' | 'doctor' | 'patient'

export interface UserProfile {
  uid: string
  email: string
  displayName: string
  role: Role
  createdAt?: string
}

export type ReadingSource = 'manual' | 'device'

export type VitalKey =
  | 'heartRate'
  | 'systolic'
  | 'diastolic'
  | 'glucose'
  | 'temperature'
  | 'spo2'
  | 'weight'

export type HealthReading = {
  id: string
  recordedAt: string
  source: ReadingSource
  deviceName?: string
  notes?: string
} & Partial<Record<VitalKey, number>>

export type IndicatorStatus = 'normal' | 'warning' | 'critical'

export interface ReferenceRange {
  normalMin: number
  normalMax: number
  warningMin: number
  warningMax: number
}

export type RangedVitalKey = Exclude<VitalKey, 'weight'>

export type ReferenceRanges = Record<RangedVitalKey, ReferenceRange>

export interface MedicalRecord {
  id: string
  patientId: string
  type: 'history' | 'diagnosis' | 'treatment' | 'lab' | 'imaging'
  title: string
  description: string
  recordedBy: string
  recordedAt: string
}

export interface Prescription {
  id: string
  patientId: string
  doctorId: string
  medication: string
  dosage: string
  frequency: string
  startDate: string
  endDate?: string
  status: 'active' | 'completed' | 'cancelled'
}

export interface Appointment {
  id: string
  patientId: string
  doctorId: string
  scheduledAt: string
  reason: string
  mode: 'in-person' | 'video'
  status: 'requested' | 'confirmed' | 'completed' | 'cancelled'
}

export interface ReportFile {
  id: string
  patientId: string
  fileName: string
  contentType: string
  size: number
  storagePath: string
  category: string
  uploadedBy: string
  uploadedAt: string
}

export interface AppNotification {
  id: string
  userId: string
  title: string
  body: string
  category: 'appointment' | 'reading' | 'record' | 'system'
  read: boolean
  createdAt: string
}

export interface ActivityLog {
  id: string
  actorId: string
  action: string
  target: string
  createdAt: string
}
